#pragma once

#include <mailio/smtp/client.hpp>
