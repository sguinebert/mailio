#pragma once

#include <string>
#include <string_view>
#include <vector>
#include <map>
#include <cstdint>
#include <functional>

namespace mailio
{
namespace smtp
{

struct reply
{
    int status = 0;
    std::vector<std::string> lines;

    [[nodiscard]] bool is_positive_completion() const noexcept { return status / 100 == 2; }
    [[nodiscard]] bool is_positive_intermediate() const noexcept { return status / 100 == 3; }
    [[nodiscard]] bool is_transient_negative() const noexcept { return status / 100 == 4; }
    [[nodiscard]] bool is_permanent_negative() const noexcept { return status / 100 == 5; }

    [[nodiscard]] std::string message() const
    {
        if (lines.empty())
            return std::string();

        std::string out = lines.front();
        for (std::size_t i = 1; i < lines.size(); ++i)
        {
            out += "\n";
            out += lines[i];
        }
        return out;
    }
};

struct capabilities
{
    std::map<std::string, std::vector<std::string>> entries;

    [[nodiscard]] bool empty() const noexcept { return entries.empty(); }

    [[nodiscard]] bool supports(std::string_view capability) const
    {
        const std::string key = normalize_key(capability);
        return entries.find(key) != entries.end();
    }

    [[nodiscard]] const std::vector<std::string>* parameters(std::string_view capability) const
    {
        const std::string key = normalize_key(capability);
        auto it = entries.find(key);
        return it == entries.end() ? nullptr : &it->second;
    }

private:
    [[nodiscard]] static std::string normalize_key(std::string_view key)
    {
        std::string out;
        out.reserve(key.size());
        for (char ch : key)
        {
            if (ch >= 'a' && ch <= 'z')
                out.push_back(static_cast<char>(ch - ('a' - 'A')));
            else
                out.push_back(ch);
        }
        return out;
    }
};

struct envelope
{
    std::string mail_from;
    std::vector<std::string> rcpt_to;
};

enum class auth_method
{
    auto_detect,
    plain,
    login,
    xoauth2
};

// ==================== Progress Callback Types ====================

/**
 * Progress information for large message transfers.
 */
struct progress_info_t
{
    uint64_t bytes_transferred = 0;  ///< Bytes transferred so far
    uint64_t total_bytes = 0;        ///< Total bytes to transfer
    bool is_upload = true;           ///< Always true for SMTP (sending)
    
    /// Returns progress as a percentage (0-100), or -1 if total is unknown
    [[nodiscard]] double percent() const noexcept
    {
        return total_bytes > 0 ? (static_cast<double>(bytes_transferred) / total_bytes) * 100.0 : -1.0;
    }
    
    [[nodiscard]] bool is_complete() const noexcept
    {
        return total_bytes > 0 && bytes_transferred >= total_bytes;
    }
};

/// Progress callback signature
using progress_callback_t = std::function<void(const progress_info_t&)>;

} // namespace smtp
} // namespace mailio
