#pragma once

#include <string>
#include <vector>
#include <optional>
#include <cstddef>
#include <mailio/net/dialog.hpp>
#include <mailio/net/upgradable_stream.hpp>

namespace mailio::imap
{

enum class status
{
    ok,
    no,
    bad,
    preauth,
    bye,
    unknown
};

struct response
{
    std::string tag;
    status st = status::unknown;
    std::string text;
    std::vector<std::string> untagged_lines;
    std::vector<std::string> continuation;
    std::vector<std::string> tagged_lines;
    std::vector<std::string> literals;
};

struct options
{
    std::size_t max_line_length = mailio::net::DEFAULT_MAX_LINE_LENGTH;
    std::optional<mailio::net::dialog<mailio::net::upgradable_stream>::duration> timeout = std::nullopt;
};

} // namespace mailio::imap
