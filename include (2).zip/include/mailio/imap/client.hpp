/*

imap.hpp
--------

Copyright (C) 2016, Tomislav Karastojkovic (http://www.alepho.com).

Distributed under the FreeBSD license, see the accompanying file LICENSE or
copy at http://www.freebsd.org/copyright/freebsd-license.html.

*/


#pragma once

#include <algorithm>
#include <array>
#include <charconv>
#include <string>
#include <string_view>
#include <cstdint>
#include <vector>
#include <list>
#include <map>
#include <utility>
#include <optional>
#include <variant>
#include <sstream>
#include <cctype>
#include <stdexcept>
#include <locale>
#include <memory>
#include <chrono>
#include <format>
#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/range/adaptor/transformed.hpp>
#include <mailio/detail/asio_decl.hpp>
#include <mailio/detail/log.hpp>
#include <mailio/net/dialog.hpp>
#include <mailio/net/upgradable_stream.hpp>
#include <mailio/mime/message.hpp>
#include <mailio/codec/codec.hpp>
#include <mailio/detail/append.hpp>
#include <mailio/detail/async_mutex.hpp>
#include <mailio/detail/sasl.hpp>
#include <mailio/detail/sanitize.hpp>
#include <mailio/detail/reconnection.hpp>
#include <mailio/imap/types.hpp>
#include <mailio/imap/error.hpp>
#include <mailio/export.hpp>


namespace mailio
{

// Import Asio types from centralized declarations
using namespace mailio::asio;

/// Reconnection policy alias for IMAP
using reconnection_policy = mailio::detail::reconnection_policy;

class MAILIO_EXPORT imap_error : public std::runtime_error
{
public:
    explicit imap_error(const std::string& msg) : std::runtime_error(msg)
    {
    }

    explicit imap_error(const char* msg) : std::runtime_error(msg)
    {
    }
};


class MAILIO_EXPORT imap_base
{
public:
    inline static const std::string UNTAGGED_RESPONSE{"*"};
    inline static const std::string CONTINUE_RESPONSE{"+"};
    inline static const std::string RANGE_SEPARATOR{":"};
    inline static const std::string RANGE_ALL{"*"};
    inline static const std::string LIST_SEPARATOR{","};
    inline static const std::string TOKEN_SEPARATOR_STR{" "};
    inline static const std::string QUOTED_STRING_SEPARATOR{"\""};

    struct mailbox_stat_t
    {
        unsigned long messages_no = 0;
        unsigned long recent_messages_no = 0;
        unsigned long uid_next = 0;
        unsigned long uid_validity = 0;
        unsigned long unseen_messages_no = 0;
        
        [[nodiscard]] bool empty() const noexcept
        {
            return messages_no == 0 && recent_messages_no == 0;
        }
    };

    struct mailbox_folder_attr_t
    {
        bool no_select = false;
        bool no_inferiors = false;
        bool marked = false;
        bool unmarked = false;
        bool has_children = false;
        bool has_no_children = false;
    };

    struct mailbox_folder_t
    {
        mailbox_folder_attr_t attr;
        char delimiter = '/';
        std::string name;
        
        [[nodiscard]] bool is_selectable() const noexcept { return !attr.no_select; }
        [[nodiscard]] bool can_have_children() const noexcept { return !attr.no_inferiors; }
    };

    struct fetch_msg_t
    {
        unsigned long uid = 0;
        unsigned long size = 0;
        std::vector<std::string> flags;
        
        [[nodiscard]] bool has_flag(std::string_view flag) const noexcept
        {
            for (const auto& f : flags)
                if (f == flag)
                    return true;
            return false;
        }
    };

    enum class response_status_t {OK, NO, BAD, PREAUTH, BYE, UNKNOWN};

    struct response_line_t
    {
        std::vector<std::string> fragments;
        std::vector<std::string> literals;
        
        [[nodiscard]] bool empty() const noexcept { return fragments.empty(); }
    };

    struct response_t
    {
        std::string tag;
        response_status_t status{response_status_t::UNKNOWN};
        std::string text;
        std::vector<std::string> literals;
        std::vector<response_line_t> lines;
        
        [[nodiscard]] bool ok() const noexcept { return status == response_status_t::OK; }
        [[nodiscard]] bool failed() const noexcept { return status == response_status_t::NO || status == response_status_t::BAD; }
    };

    enum class auth_method_t {LOGIN, PLAIN, XOAUTH2};

    typedef std::pair<unsigned long, std::optional<unsigned long>> messages_range_t;

    [[nodiscard]] static std::string messages_range_to_string(const messages_range_t& id_pair)
    {
        return std::to_string(id_pair.first) + (id_pair.second.has_value() ? RANGE_SEPARATOR + std::to_string(id_pair.second.value()) : RANGE_SEPARATOR + RANGE_ALL);
    }

    [[nodiscard]] static std::string messages_range_list_to_string(const std::list<messages_range_t>& ranges)
    {
        return boost::algorithm::join(ranges | boost::adaptors::transformed([](const messages_range_t& r) { return messages_range_to_string(r); }), LIST_SEPARATOR);
    }

    [[nodiscard]] static std::string to_astring(const std::string& text)
    {
        detail::ensure_no_crlf_or_nul(text, "astring");
        return codec::surround_string(codec::escape_string(text, "\"\\"));
    }

    /**
    Converting a date to IMAP date string format (dd-Mon-yyyy).
    
    @param date Date to convert.
    @return     Date as IMAP formatted string.
    **/
    static std::string imap_date_to_string(const std::chrono::year_month_day& date)
    {
        std::chrono::sys_days sd{date};
        return std::format("{:%d-%b-%Y}", sd);
    }

    struct search_condition_t
    {
        enum key_type {ALL, SID_LIST, UID_LIST, SUBJECT, BODY, FROM, TO, BEFORE_DATE, ON_DATE, SINCE_DATE, NEW, RECENT, SEEN, UNSEEN} key;

        typedef std::variant
        <
            std::monostate,
            std::string,
            std::list<messages_range_t>,
            std::chrono::year_month_day
        >
        value_type;

        value_type value;
        std::string imap_string;

        search_condition_t(key_type condition_key, value_type condition_value = value_type()) : key(condition_key), value(condition_value)
        {
            try
            {
                switch (key)
                {
                    case ALL:
                        imap_string = "ALL";
                        break;

                    case SID_LIST:
                    {
                        imap_string = messages_range_list_to_string(std::get<std::list<messages_range_t>>(value));
                        break;
                    }

                    case UID_LIST:
                    {
                        imap_string = "UID " + messages_range_list_to_string(std::get<std::list<messages_range_t>>(value));
                        break;
                    }

                    case SUBJECT:
                        imap_string = "SUBJECT " + QUOTED_STRING_SEPARATOR + std::get<std::string>(value) + QUOTED_STRING_SEPARATOR;
                        break;

                    case BODY:
                        imap_string = "BODY " + QUOTED_STRING_SEPARATOR + std::get<std::string>(value) + QUOTED_STRING_SEPARATOR;
                        break;

                    case FROM:
                        imap_string = "FROM " + QUOTED_STRING_SEPARATOR + std::get<std::string>(value) + QUOTED_STRING_SEPARATOR;
                        break;

                    case TO:
                        imap_string = "TO " + QUOTED_STRING_SEPARATOR + std::get<std::string>(value) + QUOTED_STRING_SEPARATOR;
                        break;

                    case BEFORE_DATE:
                        imap_string = "BEFORE " + imap_date_to_string(std::get<std::chrono::year_month_day>(value));
                        break;

                    case ON_DATE:
                        imap_string = "ON " + imap_date_to_string(std::get<std::chrono::year_month_day>(value));
                        break;

                    case SINCE_DATE:
                        imap_string = "SINCE " + imap_date_to_string(std::get<std::chrono::year_month_day>(value));
                        break;

                    case NEW:
                        imap_string = "NEW";
                        break;

                    case RECENT:
                        imap_string = "RECENT";
                        break;

                    case SEEN:
                        imap_string = "SEEN";
                        break;

                    case UNSEEN:
                        imap_string = "UNSEEN";
                        break;
                }
            }
            catch (...)
            {
                throw imap_error("Invalid search condition.");
            }
        }
    };

    // ==================== NAMESPACE Types (RFC 2342) ====================

    /**
     * Represents a single namespace entry.
     * Example: (("" "/")) means prefix="" and delimiter='/'
     */
    struct namespace_entry_t
    {
        std::string prefix;      ///< Namespace prefix (e.g., "", "INBOX.", "#news.")
        char delimiter = '/';    ///< Hierarchy delimiter
        std::map<std::string, std::string> extensions;  ///< Optional extensions
    };

    /**
     * Complete NAMESPACE response containing personal, other users', and shared namespaces.
     * RFC 2342 defines three categories of namespaces.
     */
    struct namespace_t
    {
        std::vector<namespace_entry_t> personal;   ///< User's personal mailboxes
        std::vector<namespace_entry_t> other_users; ///< Other users' mailboxes (if accessible)
        std::vector<namespace_entry_t> shared;      ///< Shared/public mailboxes
        
        [[nodiscard]] bool empty() const noexcept
        {
            return personal.empty() && other_users.empty() && shared.empty();
        }
        
        /// Get the primary delimiter for personal namespace
        [[nodiscard]] char primary_delimiter() const noexcept
        {
            return personal.empty() ? '/' : personal.front().delimiter;
        }
    };

    // ==================== QUOTA Types (RFC 2087) ====================

    /**
     * Resource usage in a quota root.
     */
    struct quota_resource_t
    {
        std::string name;        ///< Resource name (STORAGE, MESSAGE, etc.)
        uint64_t usage = 0;      ///< Current usage
        uint64_t limit = 0;      ///< Maximum allowed
        
        /// Returns usage as a percentage (0-100)
        [[nodiscard]] double percent_used() const noexcept
        {
            return limit > 0 ? (static_cast<double>(usage) / limit) * 100.0 : 0.0;
        }
        
        /// Check if quota is exceeded
        [[nodiscard]] bool is_exceeded() const noexcept
        {
            return usage >= limit && limit > 0;
        }
        
        /// Check if quota is near limit (>90% by default)
        [[nodiscard]] bool is_warning(double threshold = 90.0) const noexcept
        {
            return percent_used() >= threshold;
        }
    };

    /**
     * Quota root with its resources.
     */
    struct quota_t
    {
        std::string root_name;                    ///< Quota root name
        std::vector<quota_resource_t> resources;  ///< Resource limits
        
        /// Get storage quota (in KB)
        [[nodiscard]] std::optional<quota_resource_t> storage() const noexcept
        {
            for (const auto& r : resources)
                if (r.name == "STORAGE")
                    return r;
            return std::nullopt;
        }
        
        /// Get message count quota
        [[nodiscard]] std::optional<quota_resource_t> messages() const noexcept
        {
            for (const auto& r : resources)
                if (r.name == "MESSAGE")
                    return r;
            return std::nullopt;
        }
    };

    /**
     * Result of GETQUOTAROOT command.
     */
    struct quota_root_t
    {
        std::string mailbox;                ///< Queried mailbox name
        std::vector<std::string> roots;     ///< Quota root names that apply
        std::vector<quota_t> quotas;        ///< Quota information for each root
    };

    // ==================== Progress Callback Types ====================

    /**
     * Progress information for large data transfers.
     */
    struct progress_info_t
    {
        uint64_t bytes_transferred = 0;  ///< Bytes transferred so far
        uint64_t total_bytes = 0;        ///< Total bytes (0 if unknown)
        bool is_upload = false;          ///< True for uploads, false for downloads
        
        /// Returns progress as a percentage (0-100), or -1 if total is unknown
        [[nodiscard]] double percent() const noexcept
        {
            return total_bytes > 0 ? (static_cast<double>(bytes_transferred) / total_bytes) * 100.0 : -1.0;
        }
        
        [[nodiscard]] bool is_complete() const noexcept
        {
            return total_bytes > 0 && bytes_transferred >= total_bytes;
        }
    };

    /// Progress callback signature
    using progress_callback_t = std::function<void(const progress_info_t&)>;

    // ==================== SORT/THREAD Types (RFC 5256) ====================

    /**
     * Sort criteria for SORT command (RFC 5256).
     */
    enum class sort_key_t
    {
        ARRIVAL,    ///< Internal date (when message was received)
        CC,         ///< CC field
        DATE,       ///< Date header
        FROM,       ///< From field
        SIZE,       ///< Size of message (RFC822.SIZE)
        SUBJECT,    ///< Subject header (base subject)
        TO          ///< To field
    };

    /**
     * Sort criterion with optional reverse flag.
     */
    struct sort_criterion_t
    {
        sort_key_t key;
        bool reverse = false;
        
        sort_criterion_t(sort_key_t k, bool rev = false) : key(k), reverse(rev) {}
        
        [[nodiscard]] std::string to_string() const
        {
            std::string s;
            if (reverse) s = "REVERSE ";
            switch (key)
            {
                case sort_key_t::ARRIVAL: s += "ARRIVAL"; break;
                case sort_key_t::CC:      s += "CC"; break;
                case sort_key_t::DATE:    s += "DATE"; break;
                case sort_key_t::FROM:    s += "FROM"; break;
                case sort_key_t::SIZE:    s += "SIZE"; break;
                case sort_key_t::SUBJECT: s += "SUBJECT"; break;
                case sort_key_t::TO:      s += "TO"; break;
            }
            return s;
        }
    };

    /**
     * Threading algorithm for THREAD command (RFC 5256).
     */
    enum class thread_algorithm_t
    {
        ORDEREDSUBJECT,  ///< Simple threading by normalized subject and date
        REFERENCES       ///< Threading using References and In-Reply-To headers
    };

    /**
     * Thread node in a threaded message tree.
     * Each node contains a message number/UID and child threads.
     */
    struct thread_node_t
    {
        unsigned long id = 0;  ///< Message sequence number or UID (0 for dummy/missing parent)
        std::vector<thread_node_t> children;  ///< Child messages in thread
        
        [[nodiscard]] bool is_dummy() const noexcept { return id == 0; }
        [[nodiscard]] bool has_children() const noexcept { return !children.empty(); }
        
        /// Get all message IDs in this thread (depth-first)
        [[nodiscard]] std::vector<unsigned long> all_ids() const
        {
            std::vector<unsigned long> result;
            collect_ids(result);
            return result;
        }
        
    private:
        void collect_ids(std::vector<unsigned long>& out) const
        {
            if (id != 0) out.push_back(id);
            for (const auto& child : children)
                child.collect_ids(out);
        }
    };
};


    template<typename Stream>
    class imap_client : public imap_base
    {
    public:
        struct response_token_t
        {
            enum class token_type_t {ATOM, LITERAL, LIST} token_type;
            std::string atom;
            std::string literal;
            std::string literal_size;
            std::list<std::shared_ptr<response_token_t>> parenthesized_list;
        };

        imap_client(Stream stream)
            : dlg_(std::move(stream)),
              mutex_(dlg_.stream().get_executor())
        {
            reset_response_parser();
        }

        imap_client(mailio::net::dialog<Stream> dlg)
            : dlg_(std::move(dlg)),
              mutex_(dlg_.stream().get_executor())
        {
            reset_response_parser();
        }

        awaitable<void> connect(const std::string& host, const std::string& service)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_await connect_impl(host, service);
        }

        awaitable<void> connect(const std::string& host, unsigned short port)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_await connect_impl(host, std::to_string(port));
        }

        awaitable<response_t> read_greeting()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await read_greeting_impl();
        }

        awaitable<response_t> command(std::string command)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await command_impl(std::move(command));
        }

        awaitable<response_t> capability()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await capability_impl();
        }

        awaitable<response_t> login(std::string username, std::string password)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await login_impl(std::move(username), std::move(password));
        }

        /**
         * Authenticate using SASL PLAIN mechanism.
         */
        awaitable<response_t> authenticate_plain(const std::string& username, const std::string& password)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await authenticate_plain_impl(username, password);
        }

        /**
         * Authenticate using XOAUTH2 mechanism for OAuth2.
         * Use this with Gmail, Outlook, and other OAuth2 providers.
         * 
         * @param username The email address
         * @param access_token The OAuth2 access token (not refresh token)
         */
        awaitable<response_t> authenticate_xoauth2(const std::string& username, const std::string& access_token)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await authenticate_xoauth2_impl(username, access_token);
        }

        /**
         * Authenticate using the specified method.
         */
        awaitable<response_t> authenticate(const std::string& username, const std::string& credential, auth_method_t method)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await authenticate_impl(username, credential, method);
        }

        /**
         * Authenticate using OAuth2 access token.
         * Convenience method for OAuth2 authentication.
         */
        awaitable<response_t> authenticate_oauth2(const std::string& username, const std::string& access_token)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await authenticate_xoauth2_impl(username, access_token);
        }

        awaitable<response_t> logout()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await logout_impl();
        }

        template<typename SSLContext>
        awaitable<imap_client<ssl::stream<Stream>>> start_tls(SSLContext& context)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await start_tls_impl(context);
        }

        // ==================== Mailbox Commands ====================

        /**
         * NOOP command - Keep connection alive.
         */
        awaitable<response_t> noop()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await noop_impl();
        }

        /**
         * SELECT command - Open a mailbox for read/write access.
         * @param mailbox The mailbox name (e.g., "INBOX")
         * @return Response containing mailbox status (EXISTS, RECENT, FLAGS, etc.)
         */
        awaitable<std::pair<response_t, mailbox_stat_t>> select(const std::string& mailbox)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await select_impl(mailbox);
        }

        /**
         * EXAMINE command - Open a mailbox for read-only access.
         * @param mailbox The mailbox name
         * @return Response containing mailbox status
         */
        awaitable<std::pair<response_t, mailbox_stat_t>> examine(const std::string& mailbox)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await examine_impl(mailbox);
        }

        /**
         * CREATE command - Create a new mailbox.
         * @param mailbox The mailbox name to create
         */
        awaitable<response_t> create(const std::string& mailbox)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await create_impl(mailbox);
        }

        /**
         * DELETE command - Delete a mailbox.
         * @param mailbox The mailbox name to delete
         */
        awaitable<response_t> delete_mailbox(const std::string& mailbox)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await delete_impl(mailbox);
        }

        /**
         * RENAME command - Rename a mailbox.
         * @param old_name Current mailbox name
         * @param new_name New mailbox name
         */
        awaitable<response_t> rename(const std::string& old_name, const std::string& new_name)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await rename_impl(old_name, new_name);
        }

        /**
         * LIST command - List mailboxes matching a pattern.
         * @param reference Reference name (usually "")
         * @param pattern Mailbox pattern (* and % wildcards)
         * @return List of mailbox folders
         */
        awaitable<std::pair<response_t, std::vector<mailbox_folder_t>>> list(const std::string& reference, const std::string& pattern)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await list_impl(reference, pattern);
        }

        /**
         * CLOSE command - Close the selected mailbox and expunge deleted messages.
         */
        awaitable<response_t> close()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await close_impl();
        }

        /**
         * EXPUNGE command - Permanently remove messages marked as deleted.
         * @return List of expunged message sequence numbers
         */
        awaitable<std::pair<response_t, std::vector<unsigned long>>> expunge()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await expunge_impl();
        }

        /**
         * STATUS command - Get mailbox status without selecting it.
         * @param mailbox The mailbox name
         * @param items Status items to query (e.g., "MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY")
         * @return Mailbox statistics
         */
        awaitable<std::pair<response_t, mailbox_stat_t>> status(const std::string& mailbox, 
            const std::vector<std::string>& items = {"MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY"})
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await status_impl(mailbox, items);
        }

        /**
         * APPEND command - Upload a message to a mailbox.
         * @param mailbox Destination mailbox (e.g., "INBOX", "Sent")
         * @param message The RFC 2822 formatted message content
         * @param flags Optional flags to set (e.g., "\\Seen", "\\Draft")
         * @param date Optional internal date (if empty, server uses current time)
         * @return Response with APPENDUID if server supports UIDPLUS
         */
        awaitable<response_t> append(const std::string& mailbox, const std::string& message,
            const std::vector<std::string>& flags = {}, const std::string& date = "")
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await append_impl(mailbox, message, flags, date);
        }

        /**
         * APPEND a MIME message object to a mailbox.
         * @param mailbox Destination mailbox
         * @param msg The message object to upload
         * @param flags Optional flags
         */
        awaitable<response_t> append(const std::string& mailbox, const mailio::mime::message& msg,
            const std::vector<std::string>& flags = {})
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            std::string message_str = msg.to_string();
            co_return co_await append_impl(mailbox, message_str, flags, "");
        }

        // ==================== Message Commands ====================

        /**
         * SEARCH command - Search for messages matching criteria.
         * @param conditions List of search conditions
         * @param uid If true, return UIDs instead of sequence numbers
         * @return List of matching message numbers/UIDs
         */
        awaitable<std::pair<response_t, std::vector<unsigned long>>> search(
            const std::list<search_condition_t>& conditions, bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await search_impl(conditions, uid);
        }

        // ==================== SORT/THREAD Commands (RFC 5256) ====================

        /**
         * SORT command - Server-side sorting of messages.
         * Requires SORT capability. More efficient than client-side sorting.
         * 
         * @param criteria Sort criteria (e.g., {DATE, true} for reverse date)
         * @param charset Character set for search criteria (usually "UTF-8")
         * @param search_conditions Search criteria to filter messages
         * @param uid If true, return UIDs instead of sequence numbers
         * @return Sorted list of message numbers/UIDs
         */
        awaitable<std::pair<response_t, std::vector<unsigned long>>> sort(
            const std::vector<sort_criterion_t>& criteria,
            const std::string& charset,
            const std::list<search_condition_t>& search_conditions,
            bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await sort_impl(criteria, charset, search_conditions, uid);
        }

        /**
         * SORT command with default charset (UTF-8) and ALL search.
         * @param criteria Sort criteria
         * @param uid If true, return UIDs
         * @return Sorted list of message numbers/UIDs
         */
        awaitable<std::pair<response_t, std::vector<unsigned long>>> sort(
            const std::vector<sort_criterion_t>& criteria,
            bool uid = false)
        {
            std::list<search_condition_t> all;
            all.emplace_back(search_condition_t::ALL);
            return sort(criteria, "UTF-8", all, uid);
        }

        /**
         * THREAD command - Server-side message threading.
         * Requires THREAD capability. Returns messages organized into threads.
         * 
         * @param algorithm Threading algorithm (ORDEREDSUBJECT or REFERENCES)
         * @param charset Character set for search criteria (usually "UTF-8")
         * @param search_conditions Search criteria to filter messages
         * @param uid If true, use UIDs instead of sequence numbers
         * @return Thread tree structure
         */
        awaitable<std::pair<response_t, std::vector<thread_node_t>>> thread(
            thread_algorithm_t algorithm,
            const std::string& charset,
            const std::list<search_condition_t>& search_conditions,
            bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await thread_impl(algorithm, charset, search_conditions, uid);
        }

        /**
         * THREAD command with default charset (UTF-8) and ALL search.
         * @param algorithm Threading algorithm
         * @param uid If true, use UIDs
         * @return Thread tree structure
         */
        awaitable<std::pair<response_t, std::vector<thread_node_t>>> thread(
            thread_algorithm_t algorithm,
            bool uid = false)
        {
            std::list<search_condition_t> all;
            all.emplace_back(search_condition_t::ALL);
            return thread(algorithm, "UTF-8", all, uid);
        }

        /**
         * FETCH command - Fetch message data.
         * @param sequence Message sequence number or range (e.g., "1", "1:5", "1,3,5")
         * @param items Data items to fetch (e.g., "FLAGS", "BODY[]", "ENVELOPE")
         * @param uid If true, interpret sequence as UIDs
         * @return Response with fetched data in literals
         */
        awaitable<response_t> fetch(const std::string& sequence, const std::string& items, bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await fetch_impl(sequence, items, uid);
        }

        /**
         * FETCH message by sequence number.
         * @param msg_num Message sequence number
         * @param items Data items to fetch
         * @param uid If true, msg_num is UID
         */
        awaitable<response_t> fetch(unsigned long msg_num, const std::string& items, bool uid = false)
        {
            return fetch(std::to_string(msg_num), items, uid);
        }

        /**
         * STORE command - Alter message flags.
         * @param sequence Message sequence or range
         * @param flags Flags to set (e.g., "\\Seen", "\\Deleted")
         * @param action "+FLAGS" to add, "-FLAGS" to remove, "FLAGS" to replace
         * @param uid If true, interpret sequence as UIDs
         */
        awaitable<response_t> store(const std::string& sequence, const std::string& flags, 
                                                  const std::string& action = "FLAGS", bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await store_impl(sequence, flags, action, uid);
        }

        /**
         * COPY command - Copy messages to another mailbox.
         * @param sequence Message sequence or range
         * @param mailbox Destination mailbox
         * @param uid If true, interpret sequence as UIDs
         */
        awaitable<response_t> copy(const std::string& sequence, const std::string& mailbox, bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await copy_impl(sequence, mailbox, uid);
        }

        /**
         * MOVE command (RFC 6851) - Move messages to another mailbox.
         * @param sequence Message sequence or range
         * @param mailbox Destination mailbox
         * @param uid If true, interpret sequence as UIDs
         */
        awaitable<response_t> move(const std::string& sequence, const std::string& mailbox, bool uid = false)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await move_impl(sequence, mailbox, uid);
        }

        // ==================== IDLE Command (RFC 2177) ====================

        /**
         * Start IDLE mode for push notifications.
         * Returns when server sends an untagged response or timeout.
         * Call done_idle() to exit IDLE mode.
         * 
         * @return Untagged responses received during IDLE
         */
        awaitable<response_t> idle()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await idle_impl();
        }

        /**
         * Start IDLE mode with a timeout.
         * RFC 2177 recommends clients restart IDLE every 29 minutes
         * as servers may close inactive connections after 30 minutes.
         * 
         * @param timeout Duration to wait before auto-terminating IDLE
         * @return Pair of (responses received, true if timeout occurred)
         */
        awaitable<std::pair<response_t, bool>> idle_with_timeout(
            std::chrono::milliseconds timeout)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await idle_with_timeout_impl(timeout);
        }

        /**
         * Exit IDLE mode by sending DONE.
         */
        awaitable<response_t> done_idle()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await done_idle_impl();
        }

        // ==================== NAMESPACE Command (RFC 2342) ====================

        /**
         * NAMESPACE command - Get server namespace configuration.
         * Useful for multi-account applications to understand mailbox hierarchy.
         * @return Namespace information (personal, other users, shared)
         */
        awaitable<std::pair<response_t, namespace_t>> get_namespace()
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await namespace_impl();
        }

        // ==================== QUOTA Commands (RFC 2087) ====================

        /**
         * GETQUOTAROOT command - Get quota roots and their quotas for a mailbox.
         * @param mailbox The mailbox to query (e.g., "INBOX")
         * @return Quota root information including storage/message limits
         */
        awaitable<std::pair<response_t, quota_root_t>> get_quota_root(const std::string& mailbox)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await getquotaroot_impl(mailbox);
        }

        /**
         * GETQUOTA command - Get quota for a specific quota root.
         * @param root The quota root name (obtained from GETQUOTAROOT)
         * @return Quota information
         */
        awaitable<std::pair<response_t, quota_t>> get_quota(const std::string& root)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await getquota_impl(root);
        }

        /**
         * SETQUOTA command - Set quota for a quota root (requires admin rights).
         * @param root The quota root name
         * @param resources Resource limits to set
         * @return Response indicating success/failure
         */
        awaitable<response_t> set_quota(const std::string& root, 
            const std::vector<std::pair<std::string, uint64_t>>& resources)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await setquota_impl(root, resources);
        }

        // ==================== Progress Callback Variants ====================

        /**
         * FETCH with progress callback for large messages/attachments.
         * @param sequence Message sequence number or range
         * @param items Data items to fetch
         * @param uid If true, interpret sequence as UIDs
         * @param progress Callback invoked during download
         */
        awaitable<response_t> fetch_with_progress(
            const std::string& sequence, 
            const std::string& items, 
            bool uid,
            progress_callback_t progress)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await fetch_with_progress_impl(sequence, items, uid, std::move(progress));
        }

        /**
         * APPEND with progress callback for large uploads.
         * @param mailbox Destination mailbox
         * @param message The message content
         * @param flags Optional flags
         * @param date Optional internal date
         * @param progress Callback invoked during upload
         */
        awaitable<response_t> append_with_progress(
            const std::string& mailbox,
            const std::string& message,
            const std::vector<std::string>& flags,
            const std::string& date,
            progress_callback_t progress)
        {
            [[maybe_unused]] auto guard = co_await mutex_.lock();
            co_return co_await append_with_progress_impl(mailbox, message, flags, date, std::move(progress));
        }

        // ==================== Auto-Reconnection ====================

        /**
         * Set reconnection policy for automatic reconnection on failures.
         * @param policy The reconnection policy to use
         */
        void set_reconnection_policy(reconnection_policy policy)
        {
            reconnection_policy_ = std::move(policy);
        }

        /**
         * Get current reconnection policy.
         */
        const reconnection_policy& reconnection_policy_config() const
        {
            return reconnection_policy_;
        }

        /**
         * Check if auto-reconnection is enabled.
         */
        bool auto_reconnection_enabled() const
        {
            return reconnection_policy_.enabled;
        }

        /**
         * Execute a fetch operation with auto-reconnection.
         * If the connection is lost, automatically reconnects and retries.
         * 
         * @param sequence Message sequence or UID range
         * @param items Items to fetch
         * @param uid Use UIDs instead of sequence numbers
         * @param credentials Credentials for re-authentication (username, password, method)
         * @param mailbox Mailbox to re-select after reconnection
         * @return Fetch response
         */
        awaitable<response_t> fetch_with_reconnection(
            const std::string& sequence,
            const std::string& items,
            bool uid,
            const std::tuple<std::string, std::string, auth_method_t>& credentials,
            const std::string& mailbox)
        {
            if (!reconnection_policy_.enabled)
                co_return co_await fetch(sequence, items, uid);
            
            unsigned int attempt = 0;
            std::exception_ptr last_error;
            
            while (true)
            {
                try
                {
                    co_return co_await fetch(sequence, items, uid);
                }
                catch (const std::exception& e)
                {
                    last_error = std::current_exception();
                    
                    if (!is_connection_error(e))
                        std::rethrow_exception(last_error);
                    
                    ++attempt;
                    
                    if (reconnection_policy_.max_attempts > 0 && 
                        attempt > reconnection_policy_.max_attempts)
                    {
                        if (reconnection_policy_.on_reconnect_failed)
                            reconnection_policy_.on_reconnect_failed(e);
                        std::rethrow_exception(last_error);
                    }
                    
                    auto delay = reconnection_policy_.calculate_delay(attempt);
                    
                    if (reconnection_policy_.on_reconnect_attempt)
                    {
                        if (!reconnection_policy_.on_reconnect_attempt(attempt, delay))
                            std::rethrow_exception(last_error);
                    }
                    
                    // Wait before reconnecting
                    steady_timer timer(dlg_.stream().get_executor());
                    timer.expires_after(delay);
                    co_await timer.async_wait(use_awaitable);
                    
                    // Try to reconnect
                    try
                    {
                        co_await reconnect_impl(credentials, mailbox);
                        
                        if (reconnection_policy_.on_reconnect_success)
                            reconnection_policy_.on_reconnect_success();
                    }
                    catch (const std::exception&)
                    {
                        // Connection failed, try again
                        continue;
                    }
                }
            }
        }

        // ==================== Async Wrappers ====================

        template<typename CompletionToken>
        auto async_read_greeting(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<void>
                {
                    co_await read_greeting();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_authenticate(const std::string& username, const std::string& password, CompletionToken&& token)
        {
            return async_authenticate(username, password, auth_method_t::LOGIN, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_authenticate(const std::string& username, const std::string& credential, auth_method_t method, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, username, credential, method]() -> awaitable<void>
                {
                    co_await authenticate(username, credential, method);
                }, std::forward<CompletionToken>(token));
        }

        /**
         * Authenticate using OAuth2 access token.
         */
        template<typename CompletionToken>
        auto async_authenticate_oauth2(const std::string& username, const std::string& access_token, CompletionToken&& token)
        {
            return async_authenticate(username, access_token, auth_method_t::XOAUTH2, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_logout(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<void>
                {
                    co_await logout();
                }, std::forward<CompletionToken>(token));
        }

        template<typename SSLContext, typename CompletionToken>
        auto starttls(SSLContext& context, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, &context]() -> awaitable<imap_client<ssl::stream<Stream>>>
                {
                    co_return co_await start_tls(context);
                }, std::forward<CompletionToken>(token));
        }

        // ==================== Async Mailbox Commands ====================

        template<typename CompletionToken>
        auto async_noop(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<response_t>
                {
                    co_return co_await noop();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_select(const std::string& mailbox, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox]() -> awaitable<std::pair<response_t, mailbox_stat_t>>
                {
                    co_return co_await select(mailbox);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_examine(const std::string& mailbox, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox]() -> awaitable<std::pair<response_t, mailbox_stat_t>>
                {
                    co_return co_await examine(mailbox);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_create(const std::string& mailbox, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox]() -> awaitable<response_t>
                {
                    co_return co_await create(mailbox);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_delete(const std::string& mailbox, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox]() -> awaitable<response_t>
                {
                    co_return co_await delete_mailbox(mailbox);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_rename(const std::string& old_name, const std::string& new_name, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, old_name, new_name]() -> awaitable<response_t>
                {
                    co_return co_await rename(old_name, new_name);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_list(const std::string& reference, const std::string& pattern, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, reference, pattern]() -> awaitable<std::pair<response_t, std::vector<mailbox_folder_t>>>
                {
                    co_return co_await list(reference, pattern);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_close(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<response_t>
                {
                    co_return co_await close();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_expunge(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<std::pair<response_t, std::vector<unsigned long>>>
                {
                    co_return co_await expunge();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_status(const std::string& mailbox, const std::vector<std::string>& items, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox, items]() -> awaitable<std::pair<response_t, mailbox_stat_t>>
                {
                    co_return co_await status(mailbox, items);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_append(const std::string& mailbox, const std::string& message,
                         const std::vector<std::string>& flags, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox, message, flags]() -> awaitable<response_t>
                {
                    co_return co_await append(mailbox, message, flags);
                }, std::forward<CompletionToken>(token));
        }

        // ==================== Async Message Commands ====================

        template<typename CompletionToken>
        auto async_search(const std::list<search_condition_t>& conditions, bool uid, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, conditions, uid]() -> awaitable<std::pair<response_t, std::vector<unsigned long>>>
                {
                    co_return co_await search(conditions, uid);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_fetch(const std::string& sequence, const std::string& items, bool uid, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, sequence, items, uid]() -> awaitable<response_t>
                {
                    co_return co_await fetch(sequence, items, uid);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_store(const std::string& sequence, const std::string& flags, 
                        const std::string& action, bool uid, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, sequence, flags, action, uid]() -> awaitable<response_t>
                {
                    co_return co_await store(sequence, flags, action, uid);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_copy(const std::string& sequence, const std::string& mailbox, bool uid, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, sequence, mailbox, uid]() -> awaitable<response_t>
                {
                    co_return co_await copy(sequence, mailbox, uid);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_move(const std::string& sequence, const std::string& mailbox, bool uid, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, sequence, mailbox, uid]() -> awaitable<response_t>
                {
                    co_return co_await move(sequence, mailbox, uid);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_idle(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<response_t>
                {
                    co_return co_await idle();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_done_idle(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<response_t>
                {
                    co_return co_await done_idle();
                }, std::forward<CompletionToken>(token));
        }

        // ==================== Async NAMESPACE/QUOTA Wrappers ====================

        template<typename CompletionToken>
        auto async_get_namespace(CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this]() -> awaitable<std::pair<response_t, namespace_t>>
                {
                    co_return co_await get_namespace();
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_get_quota_root(const std::string& mailbox, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox]() -> awaitable<std::pair<response_t, quota_root_t>>
                {
                    co_return co_await get_quota_root(mailbox);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_get_quota(const std::string& root, CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, root]() -> awaitable<std::pair<response_t, quota_t>>
                {
                    co_return co_await get_quota(root);
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_fetch_with_progress(
            const std::string& sequence,
            const std::string& items,
            bool uid,
            progress_callback_t progress,
            CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, sequence, items, uid, progress = std::move(progress)]() mutable -> awaitable<response_t>
                {
                    co_return co_await fetch_with_progress(sequence, items, uid, std::move(progress));
                }, std::forward<CompletionToken>(token));
        }

        template<typename CompletionToken>
        auto async_append_with_progress(
            const std::string& mailbox,
            const std::string& message,
            const std::vector<std::string>& flags,
            const std::string& date,
            progress_callback_t progress,
            CompletionToken&& token)
        {
            return co_spawn(dlg_.stream().get_executor(),
                [this, mailbox, message, flags, date, progress = std::move(progress)]() mutable -> awaitable<response_t>
                {
                    co_return co_await append_with_progress(mailbox, message, flags, date, std::move(progress));
                }, std::forward<CompletionToken>(token));
        }

    private:
        awaitable<void> connect_impl(const std::string& host, const std::string& service)
        {
            // Save for auto-reconnection
            saved_host_ = host;
            saved_service_ = service;
            
            tcp::resolver resolver(dlg_.stream().get_executor());
            auto endpoints = co_await resolver.async_resolve(host, service, use_awaitable);
            co_await async_connect(dlg_.stream().lowest_layer(), endpoints, use_awaitable);
        }

        awaitable<response_t> read_greeting_impl()
        {
            response_line_t line = co_await read_response_line();
            if (line.fragments.empty())
                throw imap_error("Parser failure.");

            auto [status, text] = parse_untagged_status(line.fragments.front());
            if (status != response_status_t::OK && status != response_status_t::PREAUTH && status != response_status_t::BYE)
                throw imap_error("Invalid greeting.");

            response_t response;
            response.status = status;
            response.text = std::move(text);
            response.lines.push_back(std::move(line));
            co_return response;
        }

        awaitable<response_t> command_impl(std::string command)
        {
            response_t response;
            response.tag = co_await send_command(command);
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("Parser failure.");
                std::string head = line.fragments.front();
                bool tagged = is_tagged_response(head, response.tag);
                if (!line.literals.empty())
                {
                    response.literals.reserve(response.literals.size() + line.literals.size());
                    for (auto& literal : line.literals)
                        response.literals.push_back(std::move(literal));
                }
                if (tagged)
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    if (!is_tagged_status(status))
                        throw imap_error("Invalid response status.");
                    response.lines.push_back(std::move(line));
                    break;
                }
                response.lines.push_back(std::move(line));
            }
            co_return response;
        }

        awaitable<response_t> capability_impl()
        {
            response_t response = co_await command_impl("CAPABILITY");
            ensure_ok(response, "Capability");
            co_return response;
        }

        awaitable<response_t> login_impl(std::string username, std::string password)
        {
            response_t response = co_await command_impl("LOGIN " + to_astring(username) + " " + to_astring(password));
            ensure_ok(response, "Login");
            co_return response;
        }

        awaitable<response_t> authenticate_plain_impl(const std::string& username, const std::string& password)
        {
            const std::string encoded = sasl::encode_plain(username, password);
            response_t response = co_await command_impl("AUTHENTICATE PLAIN " + encoded);
            
            if (response.status == response_status_t::UNKNOWN && !response.lines.empty())
            {
                response = co_await command_impl(encoded);
            }
            
            ensure_ok(response, "PLAIN authentication");
            co_return response;
        }

        awaitable<response_t> authenticate_xoauth2_impl(const std::string& username, const std::string& access_token)
        {
            const std::string encoded = sasl::encode_xoauth2(username, access_token);
            response_t response = co_await command_impl("AUTHENTICATE XOAUTH2 " + encoded);
            
            if (response.status == response_status_t::UNKNOWN && !response.lines.empty())
            {
                response = co_await command_impl("");
            }
            
            ensure_ok(response, "XOAUTH2 authentication");
            co_return response;
        }

        awaitable<response_t> authenticate_impl(const std::string& username, const std::string& credential, auth_method_t method)
        {
            switch (method)
            {
                case auth_method_t::LOGIN:
                    co_return co_await login_impl(username, credential);
                case auth_method_t::PLAIN:
                    co_return co_await authenticate_plain_impl(username, credential);
                case auth_method_t::XOAUTH2:
                    co_return co_await authenticate_xoauth2_impl(username, credential);
                default:
                    throw imap_error("Unknown authentication method");
            }
        }

        awaitable<response_t> logout_impl()
        {
            response_t response = co_await command_impl("LOGOUT");
            ensure_ok(response, "Logout");
            co_return response;
        }

        template<typename SSLContext>
        awaitable<imap_client<ssl::stream<Stream>>> start_tls_impl(SSLContext& context)
        {
            response_t response = co_await command_impl("STARTTLS");
            ensure_ok(response, "STARTTLS");

            Stream& socket = dlg_.stream();
            ssl::stream<Stream> ssl_stream(std::move(socket), context);
            co_await ssl_stream.async_handshake(ssl::stream_base::client, use_awaitable);

            co_return imap_client<ssl::stream<Stream>>(std::move(ssl_stream));
        }

        // ==================== Mailbox Command Implementations ====================

        awaitable<response_t> noop_impl()
        {
            response_t response = co_await command_impl("NOOP");
            ensure_ok(response, "NOOP");
            co_return response;
        }

        awaitable<std::pair<response_t, mailbox_stat_t>> select_impl(const std::string& mailbox)
        {
            response_t response = co_await command_impl("SELECT " + to_astring(mailbox));
            ensure_ok(response, "SELECT");
            mailbox_stat_t stat = parse_mailbox_stat(response);
            co_return std::make_pair(std::move(response), std::move(stat));
        }

        awaitable<std::pair<response_t, mailbox_stat_t>> examine_impl(const std::string& mailbox)
        {
            response_t response = co_await command_impl("EXAMINE " + to_astring(mailbox));
            ensure_ok(response, "EXAMINE");
            mailbox_stat_t stat = parse_mailbox_stat(response);
            co_return std::make_pair(std::move(response), std::move(stat));
        }

        awaitable<response_t> create_impl(const std::string& mailbox)
        {
            response_t response = co_await command_impl("CREATE " + to_astring(mailbox));
            ensure_ok(response, "CREATE");
            co_return response;
        }

        awaitable<response_t> delete_impl(const std::string& mailbox)
        {
            response_t response = co_await command_impl("DELETE " + to_astring(mailbox));
            ensure_ok(response, "DELETE");
            co_return response;
        }

        awaitable<response_t> rename_impl(const std::string& old_name, const std::string& new_name)
        {
            response_t response = co_await command_impl("RENAME " + to_astring(old_name) + " " + to_astring(new_name));
            ensure_ok(response, "RENAME");
            co_return response;
        }

        awaitable<std::pair<response_t, std::vector<mailbox_folder_t>>> list_impl(const std::string& reference, const std::string& pattern)
        {
            response_t response = co_await command_impl("LIST " + to_astring(reference) + " " + to_astring(pattern));
            ensure_ok(response, "LIST");
            std::vector<mailbox_folder_t> folders = parse_list_response(response);
            co_return std::make_pair(std::move(response), std::move(folders));
        }

        awaitable<response_t> close_impl()
        {
            response_t response = co_await command_impl("CLOSE");
            ensure_ok(response, "CLOSE");
            co_return response;
        }

        awaitable<std::pair<response_t, std::vector<unsigned long>>> expunge_impl()
        {
            response_t response = co_await command_impl("EXPUNGE");
            ensure_ok(response, "EXPUNGE");
            std::vector<unsigned long> expunged = parse_expunge_response(response);
            co_return std::make_pair(std::move(response), std::move(expunged));
        }

        awaitable<std::pair<response_t, mailbox_stat_t>> status_impl(const std::string& mailbox,
            const std::vector<std::string>& items)
        {
            std::string items_str;
            for (size_t i = 0; i < items.size(); ++i)
            {
                if (i > 0) items_str += " ";
                items_str += items[i];
            }
            
            response_t response = co_await command_impl("STATUS " + to_astring(mailbox) + " (" + items_str + ")");
            ensure_ok(response, "STATUS");
            mailbox_stat_t stat = parse_status_response(response);
            co_return std::make_pair(std::move(response), std::move(stat));
        }

        awaitable<response_t> append_impl(const std::string& mailbox, const std::string& message,
            const std::vector<std::string>& flags, const std::string& date)
        {
            // Build APPEND command: APPEND <mailbox> [<flags>] [<date>] {<size>}
            std::string cmd = "APPEND " + to_astring(mailbox);
            
            // Add flags if provided
            if (!flags.empty())
            {
                cmd += " (";
                for (size_t i = 0; i < flags.size(); ++i)
                {
                    if (i > 0) cmd += " ";
                    cmd += flags[i];
                }
                cmd += ")";
            }
            
            // Add date if provided (format: "DD-Mon-YYYY HH:MM:SS +ZZZZ")
            if (!date.empty())
            {
                cmd += " \"" + date + "\"";
            }
            
            // Add literal size
            cmd += " {" + std::to_string(message.size()) + "}";
            
            // Send command and wait for continuation
            response_t response;
            response.tag = co_await send_command(cmd);
            
            // Read continuation response (+)
            response_line_t line = co_await read_response_line();
            if (line.fragments.empty() || !starts_with(line.fragments.front(), "+"))
                throw imap_error("APPEND: expected continuation response");
            
            // Send message content
            co_await dlg_.async_write_line(message);
            
            // Read final response
            while (true)
            {
                line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("APPEND: parser failure");
                
                std::string head = line.fragments.front();
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    break;
                }
                response.lines.push_back(std::move(line));
            }
            
            ensure_ok(response, "APPEND");
            co_return response;
        }

        // ==================== Message Command Implementations ====================

        awaitable<std::pair<response_t, std::vector<unsigned long>>> search_impl(
            const std::list<search_condition_t>& conditions, bool uid)
        {
            std::string cmd = uid ? "UID SEARCH" : "SEARCH";
            for (const auto& cond : conditions)
                cmd += " " + cond.imap_string;  // Use pre-computed string from search_condition_t
            
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "SEARCH");
            std::vector<unsigned long> results = parse_search_response(response);
            co_return std::make_pair(std::move(response), std::move(results));
        }

        // ==================== SORT/THREAD Implementations (RFC 5256) ====================

        awaitable<std::pair<response_t, std::vector<unsigned long>>> sort_impl(
            const std::vector<sort_criterion_t>& criteria,
            const std::string& charset,
            const std::list<search_condition_t>& search_conditions,
            bool uid)
        {
            // Build SORT command: [UID] SORT (criteria) charset search-criteria
            std::string cmd = uid ? "UID SORT (" : "SORT (";
            
            // Add sort criteria
            for (size_t i = 0; i < criteria.size(); ++i)
            {
                if (i > 0) cmd += " ";
                cmd += criteria[i].to_string();
            }
            cmd += ") " + charset;
            
            // Add search criteria
            for (const auto& cond : search_conditions)
                cmd += " " + cond.imap_string;
            
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "SORT");
            
            // Parse SORT response - same format as SEARCH
            std::vector<unsigned long> results = parse_search_response(response);
            co_return std::make_pair(std::move(response), std::move(results));
        }

        awaitable<std::pair<response_t, std::vector<thread_node_t>>> thread_impl(
            thread_algorithm_t algorithm,
            const std::string& charset,
            const std::list<search_condition_t>& search_conditions,
            bool uid)
        {
            // Build THREAD command: [UID] THREAD algorithm charset search-criteria
            std::string cmd = uid ? "UID THREAD " : "THREAD ";
            
            // Add algorithm name
            switch (algorithm)
            {
                case thread_algorithm_t::ORDEREDSUBJECT:
                    cmd += "ORDEREDSUBJECT";
                    break;
                case thread_algorithm_t::REFERENCES:
                    cmd += "REFERENCES";
                    break;
            }
            cmd += " " + charset;
            
            // Add search criteria
            for (const auto& cond : search_conditions)
                cmd += " " + cond.imap_string;
            
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "THREAD");
            
            // Parse THREAD response
            std::vector<thread_node_t> threads = parse_thread_response(response);
            co_return std::make_pair(std::move(response), std::move(threads));
        }

        awaitable<response_t> fetch_impl(const std::string& sequence, const std::string& items, bool uid)
        {
            std::string cmd = uid ? "UID FETCH" : "FETCH";
            cmd += " " + sequence + " " + items;
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "FETCH");
            co_return response;
        }

        awaitable<response_t> store_impl(const std::string& sequence, const std::string& flags, 
                                                       const std::string& action, bool uid)
        {
            std::string cmd = uid ? "UID STORE" : "STORE";
            cmd += " " + sequence + " " + action + " (" + flags + ")";
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "STORE");
            co_return response;
        }

        awaitable<response_t> copy_impl(const std::string& sequence, const std::string& mailbox, bool uid)
        {
            std::string cmd = uid ? "UID COPY" : "COPY";
            cmd += " " + sequence + " " + to_astring(mailbox);
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "COPY");
            co_return response;
        }

        awaitable<response_t> move_impl(const std::string& sequence, const std::string& mailbox, bool uid)
        {
            std::string cmd = uid ? "UID MOVE" : "MOVE";
            cmd += " " + sequence + " " + to_astring(mailbox);
            response_t response = co_await command_impl(cmd);
            ensure_ok(response, "MOVE");
            co_return response;
        }

        // ==================== IDLE Implementation ====================

        awaitable<response_t> idle_impl()
        {
            response_t response;
            response.tag = co_await send_command("IDLE");
            idle_tag_ = response.tag;  // Store tag for done_idle()
            
            // Read continuation response (+)
            response_line_t line = co_await read_response_line();
            if (line.fragments.empty() || !starts_with(line.fragments.front(), "+"))
                throw imap_error("IDLE: expected continuation response");
            
            // Wait for untagged responses (server notifications)
            while (true)
            {
                line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("IDLE: parser failure");
                
                std::string head = line.fragments.front();
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    idle_tag_.clear();  // IDLE ended
                    break;
                }
                response.lines.push_back(std::move(line));
                
                // Return on first untagged response to allow caller to process
                // Caller should call done_idle() to exit IDLE mode
                break;
            }
            co_return response;
        }

        awaitable<std::pair<response_t, bool>> idle_with_timeout_impl(
            std::chrono::milliseconds timeout)
        {
            response_t response;
            response.tag = co_await send_command("IDLE");
            idle_tag_ = response.tag;
            
            // Read continuation response (+)
            response_line_t line = co_await read_response_line();
            if (line.fragments.empty() || !starts_with(line.fragments.front(), "+"))
                throw imap_error("IDLE: expected continuation response");
            
            // Set up timer for timeout
            steady_timer timer(dlg_.stream().get_executor());
            timer.expires_after(timeout);
            
            bool timed_out = false;
            
            // Race between reading response and timeout
            using namespace operators;
            
            auto read_op = [this, &response]() -> awaitable<void>
            {
                response_line_t ln = co_await read_response_line();
                if (ln.fragments.empty())
                    throw imap_error("IDLE: parser failure");
                response.lines.push_back(std::move(ln));
            };
            
            auto timeout_op = [&timer, &timed_out]() -> awaitable<void>
            {
                error_code ec;
                co_await timer.async_wait(redirect_error(use_awaitable, ec));
                if (!ec)
                    timed_out = true;
            };
            
            // Wait for either data or timeout
            co_await (read_op() || timeout_op());
            
            timer.cancel();
            
            co_return std::make_pair(std::move(response), timed_out);
        }

        awaitable<response_t> done_idle_impl()
        {
            if (idle_tag_.empty())
                throw imap_error("DONE: not in IDLE mode");
            
            co_await dlg_.async_write_line("DONE");
            
            // Read remaining responses until tagged response from original IDLE
            response_t response;
            response.tag = idle_tag_;
            
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("DONE: parser failure");
                
                std::string head = line.fragments.front();
                // Look for the tagged response from the original IDLE command
                if (is_tagged_response(head, idle_tag_))
                {
                    auto [status, text] = parse_tagged_status(head, idle_tag_);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    idle_tag_.clear();  // IDLE ended
                    break;
                }
                response.lines.push_back(std::move(line));
            }
            co_return response;
        }

        // ==================== NAMESPACE Implementation ====================

        awaitable<std::pair<response_t, namespace_t>> namespace_impl()
        {
            response_t response;
            response.tag = co_await send_command("NAMESPACE");
            
            namespace_t ns;
            
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("NAMESPACE: parser failure");
                
                std::string head = line.fragments.front();
                
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    break;
                }
                
                // Parse "* NAMESPACE (...) (...) (...)"
                if (starts_with(head, "* NAMESPACE"))
                {
                    ns = parse_namespace_response(head);
                }
                
                response.lines.push_back(std::move(line));
            }
            
            co_return std::make_pair(std::move(response), std::move(ns));
        }

        static namespace_t parse_namespace_response(std::string_view text)
        {
            namespace_t ns;
            
            // Skip "* NAMESPACE "
            auto pos = text.find("NAMESPACE ");
            if (pos == std::string_view::npos)
                return ns;
            text = text.substr(pos + 10);
            
            // Parse three namespace lists: personal, other_users, shared
            // Each is either NIL or (("prefix" "delimiter") ...)
            auto parse_ns_list = [&text](std::vector<namespace_entry_t>& list) {
                // Skip whitespace
                while (!text.empty() && text[0] == ' ')
                    text = text.substr(1);
                
                if (starts_with(text, "NIL"))
                {
                    text = text.substr(3);
                    return;
                }
                
                if (text.empty() || text[0] != '(')
                    return;
                
                // Find matching closing paren for the outer list
                int depth = 0;
                size_t end_pos = 0;
                for (size_t i = 0; i < text.size(); ++i)
                {
                    if (text[i] == '(') depth++;
                    else if (text[i] == ')') { depth--; if (depth == 0) { end_pos = i; break; } }
                }
                
                std::string_view list_text = text.substr(1, end_pos - 1);
                text = text.substr(end_pos + 1);
                
                // Parse individual namespace entries: ("prefix" "delimiter")
                while (!list_text.empty())
                {
                    // Skip whitespace
                    while (!list_text.empty() && list_text[0] == ' ')
                        list_text = list_text.substr(1);
                    
                    if (list_text.empty() || list_text[0] != '(')
                        break;
                    
                    // Find end of this entry
                    int d = 0;
                    size_t ep = 0;
                    for (size_t i = 0; i < list_text.size(); ++i)
                    {
                        if (list_text[i] == '(') d++;
                        else if (list_text[i] == ')') { d--; if (d == 0) { ep = i; break; } }
                    }
                    
                    std::string_view entry_text = list_text.substr(1, ep - 1);
                    list_text = list_text.substr(ep + 1);
                    
                    namespace_entry_t entry;
                    
                    // Parse prefix and delimiter from entry
                    // Format: "prefix" "delimiter" or "prefix" NIL
                    auto parse_quoted = [&entry_text]() -> std::string {
                        while (!entry_text.empty() && entry_text[0] == ' ')
                            entry_text = entry_text.substr(1);
                        
                        if (entry_text.empty())
                            return "";
                        
                        if (starts_with(entry_text, "NIL"))
                        {
                            entry_text = entry_text.substr(3);
                            return "";
                        }
                        
                        if (entry_text[0] != '"')
                            return "";
                        
                        size_t end = entry_text.find('"', 1);
                        if (end == std::string_view::npos)
                            return "";
                        
                        std::string result(entry_text.substr(1, end - 1));
                        entry_text = entry_text.substr(end + 1);
                        return result;
                    };
                    
                    entry.prefix = parse_quoted();
                    std::string delim = parse_quoted();
                    entry.delimiter = delim.empty() ? '/' : delim[0];
                    
                    list.push_back(std::move(entry));
                }
            };
            
            parse_ns_list(ns.personal);
            parse_ns_list(ns.other_users);
            parse_ns_list(ns.shared);
            
            return ns;
        }

        // ==================== QUOTA Implementation ====================

        awaitable<std::pair<response_t, quota_root_t>> getquotaroot_impl(const std::string& mailbox)
        {
            response_t response;
            response.tag = co_await send_command("GETQUOTAROOT " + to_astring(mailbox));
            
            quota_root_t qr;
            qr.mailbox = mailbox;
            
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("GETQUOTAROOT: parser failure");
                
                std::string head = line.fragments.front();
                
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    break;
                }
                
                // Parse "* QUOTAROOT mailbox root1 root2 ..."
                if (starts_with(head, "* QUOTAROOT"))
                {
                    qr.roots = parse_quotaroot_response(head);
                }
                // Parse "* QUOTA root (STORAGE usage limit ...)"
                else if (starts_with(head, "* QUOTA"))
                {
                    qr.quotas.push_back(parse_quota_response(head));
                }
                
                response.lines.push_back(std::move(line));
            }
            
            co_return std::make_pair(std::move(response), std::move(qr));
        }

        awaitable<std::pair<response_t, quota_t>> getquota_impl(const std::string& root)
        {
            response_t response;
            response.tag = co_await send_command("GETQUOTA " + to_astring(root));
            
            quota_t quota;
            
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("GETQUOTA: parser failure");
                
                std::string head = line.fragments.front();
                
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    break;
                }
                
                // Parse "* QUOTA root (STORAGE usage limit ...)"
                if (starts_with(head, "* QUOTA"))
                {
                    quota = parse_quota_response(head);
                }
                
                response.lines.push_back(std::move(line));
            }
            
            co_return std::make_pair(std::move(response), std::move(quota));
        }

        awaitable<response_t> setquota_impl(const std::string& root,
            const std::vector<std::pair<std::string, uint64_t>>& resources)
        {
            std::string cmd = "SETQUOTA " + to_astring(root) + " (";
            bool first = true;
            for (const auto& [name, limit] : resources)
            {
                if (!first) cmd += " ";
                cmd += name + " " + std::to_string(limit);
                first = false;
            }
            cmd += ")";
            
            co_return co_await command_impl(std::move(cmd));
        }

        static std::vector<std::string> parse_quotaroot_response(std::string_view text)
        {
            std::vector<std::string> roots;
            
            // Skip "* QUOTAROOT "
            auto pos = text.find("QUOTAROOT ");
            if (pos == std::string_view::npos)
                return roots;
            text = text.substr(pos + 10);
            
            // Skip mailbox name (first token)
            // Can be quoted or atom
            if (!text.empty() && text[0] == '"')
            {
                auto end = text.find('"', 1);
                if (end != std::string_view::npos)
                    text = text.substr(end + 1);
            }
            else
            {
                auto space = text.find(' ');
                if (space != std::string_view::npos)
                    text = text.substr(space);
            }
            
            // Parse remaining tokens as root names
            std::istringstream iss(std::string(text));
            std::string root;
            while (iss >> root)
            {
                // Handle quoted strings
                if (!root.empty() && root.front() == '"')
                {
                    if (root.back() == '"' && root.size() > 1)
                        root = root.substr(1, root.size() - 2);
                    else
                    {
                        std::string rest;
                        std::getline(iss, rest, '"');
                        root = root.substr(1) + rest;
                    }
                }
                roots.push_back(std::move(root));
            }
            
            return roots;
        }

        static quota_t parse_quota_response(std::string_view text)
        {
            quota_t quota;
            
            // Skip "* QUOTA "
            auto pos = text.find("QUOTA ");
            if (pos == std::string_view::npos)
                return quota;
            text = text.substr(pos + 6);
            
            // Parse root name
            if (!text.empty() && text[0] == '"')
            {
                auto end = text.find('"', 1);
                if (end != std::string_view::npos)
                {
                    quota.root_name = std::string(text.substr(1, end - 1));
                    text = text.substr(end + 1);
                }
            }
            else
            {
                auto space = text.find(' ');
                if (space != std::string_view::npos)
                {
                    quota.root_name = std::string(text.substr(0, space));
                    text = text.substr(space);
                }
            }
            
            // Find resource list in parentheses
            auto paren_start = text.find('(');
            auto paren_end = text.rfind(')');
            if (paren_start == std::string_view::npos || paren_end == std::string_view::npos)
                return quota;
            
            std::string resources_str(text.substr(paren_start + 1, paren_end - paren_start - 1));
            std::istringstream iss(resources_str);
            
            // Parse "RESOURCE usage limit" triplets
            std::string name;
            uint64_t usage, limit;
            while (iss >> name >> usage >> limit)
            {
                quota_resource_t resource;
                resource.name = std::move(name);
                resource.usage = usage;
                resource.limit = limit;
                quota.resources.push_back(std::move(resource));
            }
            
            return quota;
        }

        // ==================== Progress Callback Implementation ====================

        awaitable<response_t> fetch_with_progress_impl(
            const std::string& sequence,
            const std::string& items,
            bool uid,
            progress_callback_t progress)
        {
            std::string cmd = uid ? "UID FETCH " : "FETCH ";
            cmd += sequence + " " + items;
            
            response_t response;
            response.tag = co_await send_command(cmd);
            
            uint64_t total_bytes = 0;
            uint64_t bytes_received = 0;
            
            while (true)
            {
                response_line_t line = co_await read_response_line();
                if (line.fragments.empty())
                    throw imap_error("FETCH: parser failure");
                
                std::string head = line.fragments.front();
                
                if (is_tagged_response(head, response.tag))
                {
                    auto [status, text] = parse_tagged_status(head, response.tag);
                    response.status = status;
                    response.text = std::move(text);
                    response.lines.push_back(std::move(line));
                    break;
                }
                
                // Track progress through literals
                for (const auto& literal : line.literals)
                {
                    bytes_received += literal.size();
                    
                    if (progress)
                    {
                        progress_info_t info;
                        info.bytes_transferred = bytes_received;
                        info.total_bytes = total_bytes;
                        info.is_upload = false;
                        progress(info);
                    }
                }
                
                response.lines.push_back(std::move(line));
                response.literals.insert(response.literals.end(), 
                    line.literals.begin(), line.literals.end());
            }
            
            co_return response;
        }

        awaitable<response_t> append_with_progress_impl(
            const std::string& mailbox,
            const std::string& message,
            const std::vector<std::string>& flags,
            const std::string& date,
            progress_callback_t progress)
        {
            std::string cmd = "APPEND " + to_astring(mailbox);
            
            if (!flags.empty())
            {
                cmd += " (";
                bool first = true;
                for (const auto& flag : flags)
                {
                    if (!first) cmd += " ";
                    cmd += flag;
                    first = false;
                }
                cmd += ")";
            }
            
            if (!date.empty())
            {
                cmd += " \"" + date + "\"";
            }
            
            cmd += " {" + std::to_string(message.size()) + "}";
            
            // Send command and wait for continuation
            co_await dlg_.write_line(cmd, use_awaitable);
            auto tag = make_tag();
            
            response_line_t cont_line = co_await read_response_line();
            if (cont_line.fragments.empty() || 
                !starts_with(cont_line.fragments.front(), "+"))
            {
                throw imap_error("APPEND: server rejected literal");
            }
            
            // Send message with progress tracking
            const size_t chunk_size = 8192;
            uint64_t bytes_sent = 0;
            const uint64_t total = message.size();
            
            for (size_t offset = 0; offset < message.size(); offset += chunk_size)
            {
                size_t len = std::min(chunk_size, message.size() - offset);
                co_await dlg_.write_raw(buffer(message.data() + offset, len), use_awaitable);
                
                bytes_sent += len;
                
                if (progress)
                {
                    progress_info_t info;
                    info.bytes_transferred = bytes_sent;
                    info.total_bytes = total;
                    info.is_upload = true;
                    progress(info);
                }
            }
            
            // Send CRLF to end literal
            co_await dlg_.write_line("", use_awaitable);
            
            // Read response
            co_return co_await read_tagged_response(tag);
        }

        // ==================== Response Parsing Helpers ====================

        static mailbox_stat_t parse_mailbox_stat(const response_t& response)
        {
            mailbox_stat_t stat{};
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* <number> EXISTS"
                if (text.find(" EXISTS") != std::string_view::npos)
                {
                    stat.messages_no = parse_ulong(text);
                }
                // Parse "* <number> RECENT"
                else if (text.find(" RECENT") != std::string_view::npos)
                {
                    stat.recent_messages_no = parse_ulong(text);
                }
                // Parse "* OK [UNSEEN <number>]"
                else if (auto pos = text.find("UNSEEN "); pos != std::string_view::npos)
                {
                    stat.unseen_messages_no = parse_ulong_at(text, pos + 7);
                }
                // Parse "* OK [UIDNEXT <number>]"
                else if (auto pos = text.find("UIDNEXT "); pos != std::string_view::npos)
                {
                    stat.uid_next = parse_ulong_at(text, pos + 8);
                }
                // Parse "* OK [UIDVALIDITY <number>]"
                else if (auto pos = text.find("UIDVALIDITY "); pos != std::string_view::npos)
                {
                    stat.uid_validity = parse_ulong_at(text, pos + 12);
                }
            }
            return stat;
        }

        static mailbox_stat_t parse_status_response(const response_t& response)
        {
            mailbox_stat_t stat{};
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* STATUS <mailbox> (MESSAGES <n> RECENT <n> UNSEEN <n> UIDNEXT <n> UIDVALIDITY <n>)"
                if (!starts_with(text, "* STATUS"))
                    continue;
                
                // Find the status data in parentheses
                auto paren_start = text.find('(');
                auto paren_end = text.rfind(')');
                if (paren_start == std::string_view::npos || paren_end == std::string_view::npos)
                    continue;
                
                std::string status_data(text.substr(paren_start + 1, paren_end - paren_start - 1));
                std::istringstream iss(status_data);
                std::string key;
                unsigned long value;
                
                while (iss >> key >> value)
                {
                    if (key == "MESSAGES")
                        stat.messages_no = value;
                    else if (key == "RECENT")
                        stat.recent_messages_no = value;
                    else if (key == "UNSEEN")
                        stat.unseen_messages_no = value;
                    else if (key == "UIDNEXT")
                        stat.uid_next = value;
                    else if (key == "UIDVALIDITY")
                        stat.uid_validity = value;
                }
            }
            return stat;
        }

        static std::vector<mailbox_folder_t> parse_list_response(const response_t& response)
        {
            std::vector<mailbox_folder_t> folders;
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* LIST (<flags>) <delimiter> <name>"
                if (!starts_with(text, "* LIST"))
                    continue;
                
                mailbox_folder_t folder;
                
                // Extract flags between ( and )
                auto flags_start = text.find('(');
                auto flags_end = text.find(')');
                if (flags_start != std::string_view::npos && flags_end != std::string_view::npos)
                {
                    std::string flags_str(text.substr(flags_start + 1, flags_end - flags_start - 1));
                    // Parse individual flags
                    std::istringstream iss(flags_str);
                    std::string flag;
                    while (iss >> flag)
                    {
                        if (iequals(flag, "\\Noselect"))
                            folder.attr.no_select = true;
                        else if (iequals(flag, "\\Noinferiors"))
                            folder.attr.no_inferiors = true;
                        else if (iequals(flag, "\\Marked"))
                            folder.attr.marked = true;
                        else if (iequals(flag, "\\Unmarked"))
                            folder.attr.unmarked = true;
                    }
                }
                
                // Extract delimiter and name after flags
                auto after_flags = text.substr(flags_end + 1);
                after_flags = ltrim(after_flags);
                
                // Delimiter is quoted or NIL
                if (starts_with(after_flags, "\""))
                {
                    folder.delimiter = after_flags[1];
                    after_flags = ltrim(after_flags.substr(4)); // Skip "<delimiter>" 
                }
                else if (starts_with(after_flags, "NIL"))
                {
                    folder.delimiter = '\0';
                    after_flags = ltrim(after_flags.substr(3));
                }
                
                // Name may be quoted or unquoted
                if (starts_with(after_flags, "\""))
                {
                    auto end_quote = after_flags.find('"', 1);
                    if (end_quote != std::string_view::npos)
                        folder.name = std::string(after_flags.substr(1, end_quote - 1));
                }
                else
                {
                    folder.name = std::string(after_flags);
                }
                
                folders.push_back(std::move(folder));
            }
            return folders;
        }

        static std::vector<unsigned long> parse_expunge_response(const response_t& response)
        {
            std::vector<unsigned long> expunged;
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* <number> EXPUNGE"
                if (text.find(" EXPUNGE") != std::string_view::npos)
                {
                    unsigned long num = parse_ulong(text);
                    if (num > 0)
                        expunged.push_back(num);
                }
            }
            return expunged;
        }

        static std::vector<unsigned long> parse_search_response(const response_t& response)
        {
            std::vector<unsigned long> results;
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* SEARCH <num1> <num2> ..."
                if (!starts_with(text, "* SEARCH"))
                    continue;
                
                // Parse all numbers after "* SEARCH"
                auto nums = text.substr(8); // Skip "* SEARCH"
                const char* ptr = nums.data();
                const char* end = ptr + nums.size();
                
                while (ptr < end)
                {
                    // Skip whitespace
                    while (ptr < end && (*ptr == ' ' || *ptr == '\t'))
                        ++ptr;
                    
                    if (ptr >= end)
                        break;
                    
                    unsigned long num = 0;
                    auto [next, ec] = std::from_chars(ptr, end, num);
                    if (ec == std::errc{} && next > ptr)
                    {
                        results.push_back(num);
                        ptr = next;
                    }
                    else
                    {
                        break;  // Stop on first non-number
                    }
                }
            }
            return results;
        }

        /**
         * Parse THREAD response (RFC 5256).
         * Format: * THREAD (thread1)(thread2)...
         * Each thread: (id (child1)(child2)...) or just (id) or ((child)) for dummy parent
         */
        static std::vector<thread_node_t> parse_thread_response(const response_t& response)
        {
            std::vector<thread_node_t> threads;
            for (const auto& line : response.lines)
            {
                if (line.fragments.empty())
                    continue;
                std::string_view text = line.fragments.front();
                
                // Parse "* THREAD ..."
                if (!starts_with(text, "* THREAD"))
                    continue;
                
                // Parse the thread structure after "* THREAD "
                auto data = text.substr(9); // Skip "* THREAD "
                while (!data.empty() && data[0] == ' ')
                    data.remove_prefix(1);
                
                // Parse top-level threads
                const char* ptr = data.data();
                const char* end = ptr + data.size();
                
                while (ptr < end)
                {
                    // Skip whitespace
                    while (ptr < end && *ptr == ' ')
                        ++ptr;
                    
                    if (ptr >= end)
                        break;
                    
                    if (*ptr == '(')
                    {
                        thread_node_t node;
                        ptr = parse_thread_node(ptr, end, node);
                        threads.push_back(std::move(node));
                    }
                    else
                    {
                        break;  // Unexpected character
                    }
                }
            }
            return threads;
        }

        /**
         * Parse a single thread node recursively.
         * Returns pointer to character after the closing ')'.
         */
        static const char* parse_thread_node(const char* ptr, const char* end, thread_node_t& node)
        {
            if (ptr >= end || *ptr != '(')
                return ptr;
            ++ptr;  // Skip '('
            
            // Skip whitespace
            while (ptr < end && *ptr == ' ')
                ++ptr;
            
            // Check if this is a number (message ID) or nested structure
            if (ptr < end && *ptr >= '0' && *ptr <= '9')
            {
                // Parse message ID
                unsigned long id = 0;
                auto [next, ec] = std::from_chars(ptr, end, id);
                if (ec == std::errc{})
                {
                    node.id = id;
                    ptr = next;
                }
            }
            // else: id stays 0 (dummy node)
            
            // Parse children
            while (ptr < end)
            {
                // Skip whitespace
                while (ptr < end && *ptr == ' ')
                    ++ptr;
                
                if (ptr >= end)
                    break;
                
                if (*ptr == ')')
                {
                    ++ptr;  // Skip closing ')'
                    break;
                }
                else if (*ptr == '(')
                {
                    // Child thread
                    thread_node_t child;
                    ptr = parse_thread_node(ptr, end, child);
                    node.children.push_back(std::move(child));
                }
                else if (*ptr >= '0' && *ptr <= '9')
                {
                    // Direct child ID (ORDEREDSUBJECT format: (1 2 3))
                    unsigned long id = 0;
                    auto [next, ec] = std::from_chars(ptr, end, id);
                    if (ec == std::errc{})
                    {
                        thread_node_t child;
                        child.id = id;
                        node.children.push_back(std::move(child));
                        ptr = next;
                    }
                    else
                    {
                        break;  // Parse error
                    }
                }
                else
                {
                    break;  // Unexpected character
                }
            }
            
            return ptr;
        }

        // Note: search_condition_t already pre-computes imap_string in its constructor,
        // so we use cond.imap_string directly in search_impl() instead of format_search_condition()
        // to_astring() is inherited from imap_base

        // ==================== Reconnection Helpers ====================

        /// Check if an exception indicates a connection error
        [[nodiscard]] static bool is_connection_error(const std::exception& e)
        {
            const std::string msg = e.what();
            static const char* keywords[] = {
                "connection", "disconnected", "broken pipe", "reset by peer",
                "timed out", "timeout", "eof", "end of file", "closed", "network"
            };
            for (const char* keyword : keywords)
            {
                if (msg.find(keyword) != std::string::npos)
                    return true;
            }
            return false;
        }

        /// Internal reconnection implementation
        awaitable<void> reconnect_impl(
            const std::tuple<std::string, std::string, auth_method_t>& credentials,
            const std::string& mailbox)
        {
            // Reconnect using saved connection info
            co_await connect_impl(saved_host_, saved_service_);
            co_await read_greeting_impl();
            
            // Re-authenticate
            auto [user, pass, method] = credentials;
            co_await authenticate_impl(user, pass, method);
            
            // Re-select mailbox if specified
            if (!mailbox.empty())
            {
                co_await select_impl(mailbox);
            }
        }

    protected:
        mailio::net::dialog<Stream> dlg_;
        mailio::detail::async_mutex mutex_;
        std::string idle_tag_;  // Track IDLE command tag for done_idle()
        std::string saved_host_;     ///< For auto-reconnection
        std::string saved_service_;  ///< For auto-reconnection
        reconnection_policy reconnection_policy_;  ///< Auto-reconnection configuration
        
        enum class string_literal_state_t {NONE, SIZE, WAITING, READING, DONE};
        enum class atom_state_t {NONE, PLAIN, QUOTED};

        string_literal_state_t literal_state_;
        atom_state_t atom_state_;
        bool optional_part_state_;
        unsigned int parenthesis_list_counter_;
        std::list<std::shared_ptr<response_token_t>> mandatory_part_;
        std::list<std::shared_ptr<response_token_t>> optional_part_;
        unsigned int tag_{0};

        static const char OPTIONAL_BEGIN = '[';
        static const char OPTIONAL_END = ']';
        static const char LIST_BEGIN = '(';
        static const char LIST_END = ')';
        static const char STRING_LITERAL_BEGIN = '{';
        static const char STRING_LITERAL_END = '}';
        static const char TOKEN_SEPARATOR_CHAR = ' ';
        static const char QUOTED_ATOM = '"';

        /**
         * Safe parsing of unsigned long using std::from_chars.
         * Returns 0 on failure instead of throwing.
         */
        static unsigned long parse_ulong(std::string_view text) noexcept
        {
            // Find the start of digits
            auto num_start = text.find_first_of("0123456789");
            if (num_start == std::string_view::npos)
                return 0;
            
            // Find the end of digits
            auto num_end = text.find_first_not_of("0123456789", num_start);
            if (num_end == std::string_view::npos)
                num_end = text.size();
            
            unsigned long value = 0;
            auto [ptr, ec] = std::from_chars(
                text.data() + num_start,
                text.data() + num_end,
                value
            );
            
            if (ec != std::errc{})
                return 0;
            
            return value;
        }

        /**
         * Parse unsigned long from string_view starting at given position.
         */
        static unsigned long parse_ulong_at(std::string_view text, std::size_t pos) noexcept
        {
            if (pos >= text.size())
                return 0;
            return parse_ulong(text.substr(pos));
        }

        static bool starts_with(std::string_view text, std::string_view prefix)
        {
            return text.size() >= prefix.size() && text.compare(0, prefix.size(), prefix) == 0;
        }

        static std::string_view ltrim(std::string_view text)
        {
            while (!text.empty() && text.front() == ' ')
                text.remove_prefix(1);
            return text;
        }

        static std::pair<std::string_view, std::string_view> split_token(std::string_view text)
        {
            text = ltrim(text);
            auto pos = text.find(' ');
            if (pos == std::string_view::npos)
                return {text, std::string_view{}};
            return {text.substr(0, pos), ltrim(text.substr(pos + 1))};
        }

        static bool iequals(std::string_view lhs, std::string_view rhs)
        {
            if (lhs.size() != rhs.size())
                return false;
            for (std::size_t i = 0; i < lhs.size(); ++i)
            {
                if (std::tolower(static_cast<unsigned char>(lhs[i])) != std::tolower(static_cast<unsigned char>(rhs[i])))
                    return false;
            }
            return true;
        }

        static response_status_t parse_status_atom(std::string_view atom)
        {
            if (iequals(atom, "OK"))
                return response_status_t::OK;
            if (iequals(atom, "NO"))
                return response_status_t::NO;
            if (iequals(atom, "BAD"))
                return response_status_t::BAD;
            if (iequals(atom, "PREAUTH"))
                return response_status_t::PREAUTH;
            if (iequals(atom, "BYE"))
                return response_status_t::BYE;
            return response_status_t::UNKNOWN;
        }

        static bool is_tagged_status(response_status_t status)
        {
            return status == response_status_t::OK || status == response_status_t::NO || status == response_status_t::BAD;
        }

        static std::pair<response_status_t, std::string> parse_untagged_status(std::string_view line)
        {
            if (!starts_with(line, UNTAGGED_RESPONSE))
                throw imap_error("Invalid greeting.");

            std::string_view rest = line.substr(UNTAGGED_RESPONSE.size());
            auto [status_atom, text] = split_token(rest);
            response_status_t status = parse_status_atom(status_atom);
            if (status == response_status_t::UNKNOWN)
                throw imap_error("Invalid response status.");
            return {status, std::string(text)};
        }

        static std::pair<response_status_t, std::string> parse_tagged_status(std::string_view line, std::string_view tag)
        {
            if (!starts_with(line, tag))
                throw imap_error("Invalid response tag.");

            std::string_view rest = line.substr(tag.size());
            auto [status_atom, text] = split_token(rest);
            response_status_t status = parse_status_atom(status_atom);
            if (status == response_status_t::UNKNOWN)
                throw imap_error("Invalid response status.");
            return {status, std::string(text)};
        }

        static bool is_tagged_response(std::string_view line, std::string_view tag)
        {
            if (!starts_with(line, tag))
                return false;
            if (line.size() == tag.size())
                return true;
            return line[tag.size()] == ' ';
        }

        static void ensure_ok(const response_t& response, const std::string& context)
        {
            if (response.status == response_status_t::OK)
                return;
            std::string msg = context + " failure.";
            if (!response.text.empty())
                msg += " " + response.text;
            throw imap_error(msg);
        }

        void reset_response_parser()
        {
            optional_part_.clear();
            mandatory_part_.clear();
            optional_part_state_ = false;
            atom_state_ = atom_state_t::NONE;
            parenthesis_list_counter_ = 0;
            literal_state_ = string_literal_state_t::NONE;
        }

        std::list<std::shared_ptr<response_token_t>>* find_last_token_list(std::list<std::shared_ptr<response_token_t>>& token_list)
        {
            auto* list_ptr = &token_list;
            unsigned int depth = 1;
            while (!list_ptr->empty() && list_ptr->back()->token_type == response_token_t::token_type_t::LIST && depth <= parenthesis_list_counter_)
            {
                list_ptr = &(list_ptr->back()->parenthesized_list);
                depth++;
            }
            return list_ptr;
        }

        void parse_response(const std::string& response)
        {
            std::list<std::shared_ptr<response_token_t>>* token_list;

            std::shared_ptr<response_token_t> cur_token;
            for (auto ch : response)
            {
                switch (ch)
                {
                    case OPTIONAL_BEGIN:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (optional_part_state_)
                                throw imap_error("Parser failure.");

                            optional_part_state_ = true;
                        }
                    }
                    break;

                    case OPTIONAL_END:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (!optional_part_state_)
                                throw imap_error("Parser failure.");

                            optional_part_state_ = false;
                            atom_state_ = atom_state_t::NONE;
                        }
                    }
                    break;

                    case LIST_BEGIN:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            cur_token = std::make_shared<response_token_t>();
                            cur_token->token_type = response_token_t::token_type_t::LIST;
                            token_list = optional_part_state_ ? find_last_token_list(optional_part_) : find_last_token_list(mandatory_part_);
                            token_list->push_back(cur_token);
                            parenthesis_list_counter_++;
                            atom_state_ = atom_state_t::NONE;
                        }
                    }
                    break;

                    case LIST_END:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (parenthesis_list_counter_ == 0)
                                throw imap_error("Parser failure.");

                            parenthesis_list_counter_--;
                            atom_state_ = atom_state_t::NONE;
                        }
                    }
                    break;

                    case STRING_LITERAL_BEGIN:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (literal_state_ == string_literal_state_t::SIZE)
                                throw imap_error("Parser failure.");

                            cur_token = std::make_shared<response_token_t>();
                            cur_token->token_type = response_token_t::token_type_t::LITERAL;
                            token_list = optional_part_state_ ? find_last_token_list(optional_part_) : find_last_token_list(mandatory_part_);
                            token_list->push_back(cur_token);
                            literal_state_ = string_literal_state_t::SIZE;
                            atom_state_ = atom_state_t::NONE;
                        }
                    }
                    break;

                    case STRING_LITERAL_END:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (literal_state_ == string_literal_state_t::NONE)
                                throw imap_error("Parser failure.");

                            literal_state_ = string_literal_state_t::WAITING;
                        }
                    }
                    break;

                    case TOKEN_SEPARATOR_CHAR:
                    {
                        if (atom_state_ == atom_state_t::QUOTED)
                            cur_token->atom +=ch;
                        else
                        {
                            if (cur_token != nullptr)
                            {
                                boost::trim(cur_token->atom);
                                atom_state_ = atom_state_t::NONE;
                            }
                        }
                    }
                    break;

                    case QUOTED_ATOM:
                    {
                        if (atom_state_ == atom_state_t::NONE)
                        {
                            cur_token = std::make_shared<response_token_t>();
                            cur_token->token_type = response_token_t::token_type_t::ATOM;
                            token_list = optional_part_state_ ? find_last_token_list(optional_part_) : find_last_token_list(mandatory_part_);
                            token_list->push_back(cur_token);
                            atom_state_ = atom_state_t::QUOTED;
                        }
                        else if (atom_state_ == atom_state_t::QUOTED)
                        {
                            if (token_list->back()->atom.back() != codec::BACKSLASH_CHAR)
                                atom_state_ = atom_state_t::NONE;
                            else
                                token_list->back()->atom.back() = ch;
                        }
                    }
                    break;

                    default:
                    {
                        if (ch == codec::BACKSLASH_CHAR && atom_state_ == atom_state_t::QUOTED && token_list->back()->atom.back() == codec::BACKSLASH_CHAR)
                            break;

                        if (literal_state_ == string_literal_state_t::SIZE)
                        {
                            if (!isdigit(ch))
                                throw imap_error("Parser failure.");

                            cur_token->literal_size += ch;
                        }
                        else if (literal_state_ == string_literal_state_t::WAITING)
                        {
                            throw imap_error("Parser failure.");
                        }
                        else
                        {
                            if (atom_state_ == atom_state_t::NONE)
                            {
                                cur_token = std::make_shared<response_token_t>();
                                cur_token->token_type = response_token_t::token_type_t::ATOM;
                                token_list = optional_part_state_ ? find_last_token_list(optional_part_) : find_last_token_list(mandatory_part_);
                                token_list->push_back(cur_token);
                                atom_state_ = atom_state_t::PLAIN;
                            }
                            cur_token->atom += ch;
                        }
                    }
                }
            }
        }

        std::shared_ptr<response_token_t> pending_literal_token()
        {
            if (literal_state_ != string_literal_state_t::WAITING)
                throw imap_error("Parser failure.");

            auto* token_list = optional_part_state_ ? find_last_token_list(optional_part_) : find_last_token_list(mandatory_part_);
            if (token_list->empty() || token_list->back()->token_type != response_token_t::token_type_t::LITERAL)
                throw imap_error("Parser failure.");
            return token_list->back();
        }

        awaitable<response_line_t> read_response_line()
        {
            response_line_t response;
            reset_response_parser();
            std::string line = co_await dlg_.read_line(use_awaitable);
            response.fragments.push_back(line);
            parse_response(line);
            while (literal_state_ == string_literal_state_t::WAITING)
            {
                auto token = pending_literal_token();
                std::size_t literal_size = 0;
                const auto& size_str = token->literal_size;
                auto [ptr, ec] = std::from_chars(size_str.data(), size_str.data() + size_str.size(), literal_size);
                if (ec != std::errc{})
                {
                    throw imap_error("Parser failure: invalid literal size.");
                }
                std::string literal = co_await dlg_.read_exactly(literal_size, use_awaitable);
                response.literals.push_back(literal);
                token->literal = std::move(literal);
                literal_state_ = string_literal_state_t::NONE;
                std::string continuation = co_await dlg_.read_line(use_awaitable);
                response.fragments.push_back(continuation);
                parse_response(continuation);
            }
            co_return response;
        }

        awaitable<std::string> read_response()
        {
            response_line_t line = co_await read_response_line();
            if (line.fragments.empty())
                co_return std::string();
            co_return line.fragments.front();
        }

        awaitable<std::string> send_command(const std::string& command)
        {
            std::string tag;
            mailio::detail::append_uint(tag, ++tag_);

            std::string line = tag;
            if (!command.empty())
            {
                mailio::detail::append_space(line);
                mailio::detail::append_sv(line, command);
            }
            co_await dlg_.write_line(line, use_awaitable);
            co_return tag;
        }
    };

} // namespace mailio

namespace mailio::imap
{

class client
{
public:
    using executor_type = any_io_executor;
    using tcp = tcp;
    using dialog_type = mailio::net::dialog<mailio::net::upgradable_stream>;

    explicit client(executor_type executor, options opts = {})
        : executor_(executor),
          options_(std::move(opts)),
          mutex_(executor_)
    {
    }

    explicit client(io_context& context, options opts = {})
        : client(context.get_executor(), std::move(opts))
    {
    }

    executor_type get_executor() const { return executor_; }

    awaitable<void> connect(const std::string& host, unsigned short port)
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_await connect_impl(host, std::to_string(port));
    }

    awaitable<void> connect(const std::string& host, const std::string& service)
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_await connect_impl(host, service);
    }

    awaitable<response> read_greeting()
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await read_greeting_impl();
    }

    awaitable<response> command(std::string_view cmd)
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await command_impl(cmd);
    }

    awaitable<response> capability()
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await command_impl("CAPABILITY");
    }

    awaitable<response> login(std::string_view username, std::string_view password)
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await login_impl(username, password);
    }

    awaitable<response> logout()
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await command_impl("LOGOUT");
    }

    awaitable<response> noop()
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_return co_await command_impl("NOOP");
    }

    awaitable<void> start_tls(ssl::context& context, std::string sni = {})
    {
        [[maybe_unused]] auto guard = co_await mutex_.lock();
        co_await start_tls_impl(context, std::move(sni));
    }

private:
    dialog_type& dialog()
    {
        if (!dialog_.has_value())
            throw error("Connection is not established.", "");
        return *dialog_;
    }

    awaitable<void> connect_impl(const std::string& host, const std::string& service)
    {
        if (dialog_.has_value())
            throw error("Connection is already established.", "");
        mailio::detail::ensure_no_crlf_or_nul(host, "host");
        mailio::detail::ensure_no_crlf_or_nul(service, "service");
        remote_host_ = host;

        tcp::resolver resolver(executor_);
        auto endpoints = co_await resolver.async_resolve(host, service, use_awaitable);

        mailio::net::upgradable_stream stream(executor_);
        co_await async_connect(stream.lowest_layer(), endpoints, use_awaitable);

        dialog_.emplace(std::move(stream), options_.max_line_length, options_.timeout);
        tag_counter_ = 0;
    }

    awaitable<response> read_greeting_impl()
    {
        response resp;
        std::string line = co_await dialog().read_line(use_awaitable);
        handle_line(resp, line, std::string_view{});
        std::size_t literal_size = 0;
        if (extract_literal_size(line, literal_size))
        {
            resp.literals.push_back(co_await dialog().read_exactly(literal_size, use_awaitable));
        }
        co_return resp;
    }

    awaitable<response> login_impl(std::string_view username, std::string_view password)
    {
        mailio::detail::ensure_no_crlf_or_nul(username, "username");
        mailio::detail::ensure_no_crlf_or_nul(password, "password");
        const std::string user = mailio::imap_base::to_astring(std::string(username));
        const std::string pass = mailio::imap_base::to_astring(std::string(password));
        std::string cmd = "LOGIN " + user + " " + pass;
        co_return co_await command_impl(cmd);
    }

    awaitable<void> start_tls_impl(ssl::context& context, std::string sni)
    {
        response resp = co_await command_impl("STARTTLS");
        if (resp.st != status::ok)
            throw error("STARTTLS failure.", resp.text);

        dialog_type& dlg = dialog();
        const std::size_t max_len = dlg.max_line_length();
        const auto timeout = dlg.timeout();

        mailio::net::upgradable_stream stream = std::move(dlg.stream());
        if (sni.empty())
            sni = remote_host_;
        mailio::detail::ensure_no_crlf_or_nul(sni, "sni");
        co_await stream.start_tls(context, std::move(sni));

        dialog_.emplace(std::move(stream), max_len, timeout);
    }

    awaitable<response> command_impl(std::string_view cmd)
    {
        mailio::detail::ensure_no_crlf_or_nul(cmd, "command");

        std::string tag = std::to_string(++tag_counter_);

        std::string line = tag;
        if (!cmd.empty())
        {
            mailio::detail::append_space(line);
            mailio::detail::append_sv(line, cmd);
        }

        co_await dialog().write_line(line, use_awaitable);
        co_return co_await read_response_impl(tag);
    }

    awaitable<response> read_response_impl(const std::string& tag)
    {
        response resp;
        resp.tag = tag;

        while (true)
        {
            std::string line = co_await dialog().read_line(use_awaitable);
            handle_line(resp, line, tag);

            std::size_t literal_size = 0;
            if (extract_literal_size(line, literal_size))
            {
                resp.literals.push_back(co_await dialog().read_exactly(literal_size, use_awaitable));
            }

            if (is_tagged_line(line, tag))
                break;
        }

        co_return resp;
    }

    static bool extract_literal_size(std::string_view line, std::size_t& out)
    {
        if (line.size() < 3 || line.back() != '}')
            return false;

        const auto brace = line.rfind('{');
        if (brace == std::string_view::npos)
            return false;

        std::string_view inner = line.substr(brace + 1, line.size() - brace - 2);
        if (inner.empty())
            return false;

        if (inner.back() == '+')
            inner.remove_suffix(1);
        if (inner.empty())
            return false;

        std::size_t value = 0;
        for (char ch : inner)
        {
            if (ch < '0' || ch > '9')
                return false;
            value = value * 10 + static_cast<std::size_t>(ch - '0');
        }

        out = value;
        return true;
    }

    static bool is_tagged_line(std::string_view line, std::string_view tag)
    {
        if (tag.empty() || line.size() < tag.size())
            return false;
        if (!line.starts_with(tag))
            return false;
        if (line.size() <= tag.size())
            return false;
        return line[tag.size()] == ' ';
    }

    static std::string_view ltrim(std::string_view text)
    {
        while (!text.empty() && text.front() == ' ')
            text.remove_prefix(1);
        return text;
    }

    static std::pair<std::string_view, std::string_view> split_token(std::string_view text)
    {
        text = ltrim(text);
        auto pos = text.find(' ');
        if (pos == std::string_view::npos)
            return {text, std::string_view{}};
        return {text.substr(0, pos), ltrim(text.substr(pos + 1))};
    }

    static std::string to_upper_ascii(std::string_view input)
    {
        std::string out;
        out.reserve(input.size());
        for (char ch : input)
        {
            if (ch >= 'a' && ch <= 'z')
                out.push_back(static_cast<char>(ch - ('a' - 'A')));
            else
                out.push_back(ch);
        }
        return out;
    }

    static status parse_status_word(std::string_view word)
    {
        const std::string upper = to_upper_ascii(word);
        if (upper == "OK")
            return status::ok;
        if (upper == "NO")
            return status::no;
        if (upper == "BAD")
            return status::bad;
        if (upper == "PREAUTH")
            return status::preauth;
        if (upper == "BYE")
            return status::bye;
        return status::unknown;
    }

    static void apply_status_from_untagged(response& resp, std::string_view line)
    {
        std::string_view rest = ltrim(line.substr(1));
        auto [word, tail] = split_token(rest);
        status st = parse_status_word(word);
        if (st != status::unknown && resp.st == status::unknown)
        {
            resp.st = st;
            resp.text.assign(tail.begin(), tail.end());
        }
    }

    static void apply_status_from_tagged(response& resp, std::string_view line, std::string_view tag)
    {
        std::string_view rest = ltrim(line.substr(tag.size()));
        auto [word, tail] = split_token(rest);
        status st = parse_status_word(word);
        resp.st = st;
        resp.text.assign(tail.begin(), tail.end());
    }

    static void handle_line(response& resp, const std::string& line, std::string_view tag)
    {
        if (!tag.empty() && is_tagged_line(line, tag))
        {
            resp.tagged_lines.push_back(line);
            apply_status_from_tagged(resp, line, tag);
            return;
        }

        if (!line.empty() && line[0] == '*')
        {
            resp.untagged_lines.push_back(line);
            apply_status_from_untagged(resp, line);
            return;
        }

        if (!line.empty() && line[0] == '+')
        {
            resp.continuation.push_back(line);
            if (resp.st == status::unknown && resp.text.empty())
            {
                std::string_view rest = ltrim(line.substr(1));
                resp.text.assign(rest.begin(), rest.end());
            }
            return;
        }

        resp.untagged_lines.push_back(line);
    }

    executor_type executor_;
    options options_;
    mailio::detail::async_mutex mutex_;
    std::optional<dialog_type> dialog_;
    std::string remote_host_;
    std::uint64_t tag_counter_{0};
};

} // namespace mailio::imap
