#pragma once

#include <mailio/net/dialog.hpp>

namespace mailio::pop3
{

class error : public mailio::net::dialog_error
{
public:
    using mailio::net::dialog_error::dialog_error;
};

} // namespace mailio::pop3

namespace mailio
{
using pop3_error = mailio::pop3::error;
}
