/*

imap_async_example.cpp
----------------------

Demonstrates the modern async IMAP client with C++20 coroutines.

Copyright (C) 2024, mailio contributors.

Distributed under the FreeBSD license.

*/

#include <iostream>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <mailio/imap/client.hpp>

namespace asio = boost::asio;
using asio::ip::tcp;

// Example IMAP operations using coroutines
asio::awaitable<void> run_imap_example(asio::io_context& ioc, asio::ssl::context& ssl_ctx)
{
    using namespace mailio::imap;
    using ssl_stream = asio::ssl::stream<tcp::socket>;

    try
    {
        // Create SSL socket and connect
        ssl_stream ssl_socket(ioc, ssl_ctx);
        
        // Resolve and connect to IMAP server
        tcp::resolver resolver(ioc);
        auto endpoints = co_await resolver.async_resolve("imap.example.com", "993", asio::use_awaitable);
        co_await asio::async_connect(ssl_socket.next_layer(), endpoints, asio::use_awaitable);
        co_await ssl_socket.async_handshake(asio::ssl::stream_base::client, asio::use_awaitable);

        // Create IMAP client from connected SSL stream
        imap_client<ssl_stream> client(std::move(ssl_socket));

        // Read server greeting
        auto greeting = co_await client.read_greeting();
        std::cout << "Server greeting: " << greeting.text << "\n";

        // Get server capabilities
        auto caps = co_await client.capability();
        std::cout << "Server capabilities received.\n";

        // Authenticate with OAuth2 or LOGIN
        co_await client.authenticate("user@example.com", "password", auth_method_t::LOGIN);
        std::cout << "Authenticated successfully.\n";

        // List all mailboxes
        auto [list_resp, folders] = co_await client.list("", "*");
        std::cout << "Found " << folders.size() << " mailboxes:\n";
        for (const auto& folder : folders)
        {
            std::cout << "  - " << folder.name << "\n";
        }

        // Select INBOX
        auto [select_resp, stat] = co_await client.select("INBOX");
        std::cout << "INBOX has " << stat.messages_no << " messages, "
                  << stat.messages_recent << " recent, "
                  << stat.messages_unseen << " unseen.\n";

        // Search for unseen messages
        std::list<search_condition_t> conditions;
        search_condition_t unseen_cond;
        unseen_cond.key = search_condition_t::key_type::UNSEEN;
        conditions.push_back(unseen_cond);
        
        auto [search_resp, msg_ids] = co_await client.search(conditions, false);
        std::cout << "Found " << msg_ids.size() << " unseen messages.\n";

        // Fetch first message if any exist
        if (stat.messages_no > 0)
        {
            auto fetch_resp = co_await client.fetch(1, "BODY[HEADER.FIELDS (FROM SUBJECT DATE)]", false);
            std::cout << "Fetched message headers.\n";
            
            // The response contains the fetched data in literals
            for (const auto& literal : fetch_resp.literals)
            {
                std::cout << "  " << literal << "\n";
            }
        }

        // Mark first message as seen
        if (stat.messages_no > 0)
        {
            co_await client.store("1", "\\Seen", "+FLAGS", false);
            std::cout << "Marked message as seen.\n";
        }

        // NOOP to keep connection alive
        co_await client.noop();

        // Close mailbox (expunges deleted messages)
        co_await client.close();

        // Logout
        co_await client.logout();
        std::cout << "Logged out successfully.\n";
    }
    catch (const imap_error& e)
    {
        std::cerr << "IMAP error: " << e.what() << "\n";
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error: " << e.what() << "\n";
    }
}

int main()
{
    try
    {
        asio::io_context ioc;
        
        // Setup SSL context
        asio::ssl::context ssl_ctx(asio::ssl::context::tlsv12_client);
        ssl_ctx.set_default_verify_paths();
        ssl_ctx.set_verify_mode(asio::ssl::verify_peer);

        // Run the IMAP example coroutine
        asio::co_spawn(ioc, run_imap_example(ioc, ssl_ctx), asio::detached);
        
        ioc.run();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
