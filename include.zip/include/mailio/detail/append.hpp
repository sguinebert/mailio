#pragma once

// Placeholder for append helpers (e.g., append_uint, append_sv, append_crlf).
